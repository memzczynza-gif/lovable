// @leadconnector/vite-tanstack-config already includes the following — do NOT add them manually
// or the app will break with duplicate plugins:
//   - tanstackStart, viteReact, tailwindcss, tsConfigPaths, nitro (build-only using cloudflare as a default target),
//     componentTagger (dev-only, jsxSource fallback + tailwind config), @tanstack/devtools-vite source injection (data-tsd-source, dev-only),
//     HMR gate/flush, dev-server bridge controls, server diagnostics, lightningcss, and sandbox detection
//     (secure host allowlist, port/strictPort, watch ignores, and HMR overlay policy).
// You can pass additional config via defineConfig({ vite: { ... }, etc... }) if needed.
import { defineConfig } from "@leadconnector/vite-tanstack-config";

export default defineConfig({
  // Browser errors stay in the trusted parent-frame console-log flow;
  // do not expose the bridge collector on the public sandbox tunnel.
  devServerBridge: { errorCollector: false },
  // Do not set server.hmr.timeout — Vite 8 deprecated those websocket fields
  // (use server.ws.*). Overlay/host/port are package-owned; default WS timeout is 30s.

  // IMPORTANT: do NOT disable nitro or enable spa mode here.
  // This platform's deployment artifact validator REQUIRES a server entry
  // (server/index.mjs). `nitro: false` / `spa.enabled` strip it and the build
  // fails validation with "artifact missing server/index.mjs".
  //
  // The platform deploys to a managed serverless edge worker (the nitro
  // "cloudflare" target baked into @leadconnector/vite-tanstack-config). The
  // route content is prerendered/static — the worker just serves it — so there
  // is no Node.js server for you to run or operate.
  tanstackStart: {
    // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR
    // pass-through / error wrapper). nitro/vite builds from this into
    // dist/server/index.mjs, which is what the artifact validator expects.
    server: {
      allowedHosts: true,
      entry: "server",
    },
  },
});
