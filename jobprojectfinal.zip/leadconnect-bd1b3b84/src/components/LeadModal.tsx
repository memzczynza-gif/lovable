import { useEffect } from "react";
import { X } from "lucide-react";

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: "consultation" | "gift" | "offer" | "more";
}

// JotForm embedded as an iframe. The jsform script uses document.write which
// wipes the host page when injected after load, so we use the iframe URL which
// renders the form reliably inside the modal.
const JOTFORM_URL = "https://www.jotform.com/262703848239061";

export function LeadModal({ isOpen, onClose, type }: LeadModalProps) {
  // Lock body scroll while modal is open.
  useEffect(() => {
    if (!isOpen) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [isOpen]);

  // Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const title =
    type === "gift"
      ? "Pobierz bezpłatny poradnik"
      : type === "more"
        ? "Skontaktuj się ze mną"
        : "Bezpłatna konsultacja";

  return (
    <div
      className="fixed inset-0 z-[10000] bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-2xl shadow-2xl max-w-[480px] w-full p-4 sm:p-6 relative animate-in fade-in zoom-in-95 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Zamknij"
          className="absolute top-3 right-3 p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-4 mt-1">
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900">{title}</h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Wypełnij formularz, a my skontaktujemy się z Tobą
          </p>
        </div>

        <iframe
          src={JOTFORM_URL}
          title={title}
          className="w-full rounded-lg"
          style={{ height: "560px", border: "none", minHeight: "560px" }}
          allow="geolocation; microphone; camera; autoplay"
          loading="lazy"
        />
      </div>
    </div>
  );
}
