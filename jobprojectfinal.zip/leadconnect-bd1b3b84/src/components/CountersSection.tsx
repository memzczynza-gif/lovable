import { motion } from "framer-motion";

export function CountersSection() {
  const counters = [
    {
      icon: "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68ae03609f32d811442c658e.svg",
      value: "1,000+",
      label: "Profesjonalnych CV",
    },
    {
      icon: "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68ae03609f32d811442c658e.svg",
      value: "10K+",
      label: "Godzin coachingowych i doradczych",
    },
    {
      icon: "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68ae0aa835b40978bbcbd8b7.png",
      value: "250+",
      label: "Karier budowanych na nowo",
    },
    {
      icon: "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68ae0ae6f852688ec994e094.svg",
      value: "2,000+",
      label: "Godzin przygotowań do rozmów rekrutacyjnych",
    },
    {
      icon: "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68ae0ae6f852688ec994e094.svg",
      value: "98%",
      label: "Zadowolonych klientów",
      colSpan: "col-span-2 md:col-span-1",
    },
  ];

  return (
    <section className="py-16 sm:py-24 bg-white overflow-hidden">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-12 lg:px-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-bold text-[#111111]">
            Dlaczego warto mi zaufać?
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-6 sm:gap-8 text-center items-start">
          {counters.map((c, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              whileInView={{ opacity: 1, y: 0, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              whileHover={{ scale: 1.05, transition: { duration: 0.2 } }}
              className={`flex flex-col items-center space-y-2 cursor-pointer ${c.colSpan || ""}`}
            >
              <div className="h-14 flex items-center justify-center">
                <img
                  src={c.icon}
                  alt={c.label}
                  className="h-12 w-auto object-contain transition-transform duration-300 hover:rotate-3"
                />
              </div>
              <div className="text-2xl sm:text-3xl font-bold text-[#f5dc62] tracking-tight">
                {c.value}
              </div>
              <p className="text-xs sm:text-sm text-[#444444] font-normal leading-snug">
                {c.label}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
