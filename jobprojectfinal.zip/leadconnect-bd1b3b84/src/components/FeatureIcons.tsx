// Raw SVG icons from original page embedded cleanly via dangerouslySetInnerHTML

const rawSvg1 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<g>
	<g>
		
			<circle fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="45.174" cy="49.536" r="42.964"/>
		
			<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="2.209" y1="49.537" x2="88.138" y2="49.537"/>
		
			<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="45.173" y1="6.572" x2="45.173" y2="92.5"/>
		<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M42.747,92.429
			c0,0-45.293-37.973,0-85.789"/>
		<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M48.701,92.429
			c0,0,45.292-37.973,0-85.789"/>
		<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M79.539,75.318
			c-12.605-9.65-38.032-22.18-68.416,0.373"/>
		<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M79.539,24.363
			c-12.605,9.65-38.032,22.18-68.416-0.374"/>
	</g>
</g>
<path fill="#FFFFFF" d="M55.819,94.183c0,0,31.34-29.26,23.063-67.381l18.439-14.186l14.057,52.752c0,0,5.014,30.588,3.487,31.029
	c-1.524,0.443-29.379,6.65-29.379,6.65l-29.668-8.016"/>
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M110.88,156.255"/>
<g>
	<g>
		<g>
			<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M125.58,86.958
				c-1.39-14.717-12.096-26.183-25.105-26.183c-13.011,0-23.715,11.466-25.103,26.183"/>
		</g>
		<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M117.258,42.067
			c0,9.355-7.582,16.938-16.94,16.938c-9.354,0-16.936-7.583-16.936-16.938c0-9.356,7.581-16.94,16.936-16.94
			C109.676,25.126,117.258,32.71,117.258,42.067z"/>
	</g>
</g>
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="95.212,79.833 100.387,84.789 
	105.743,79.833 101.251,64.899 99.495,64.899 "/>
</svg>`;

export function FeatureIcon1() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg1 }}
    />
  );
}

const rawSvg2 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M110.88,156.256"/>
<g>
	<g>
		<g>
			<path fill="#36B8AF" d="M72.002,65.068l-19.671-28.42c-0.323-0.468-0.206-1.106,0.26-1.429l23.211-16.067
				c11.339-7.848,24.586-11.906,38.307-11.74l3.716,0.062c0.347,0.038,0.575,0.082,0.793,0.125c2.421,0.434,4.208,2.971,3.75,5.455
				c-0.025,0.182-0.068,0.411-0.119,0.632l-1.101,3.802c-4.635,12.777-13.247,23.981-24.274,31.614L73.432,65.328
				C72.966,65.651,72.327,65.535,72.002,65.068z M54.606,36.325l18.503,26.729l22.596-15.642
				c10.679-7.392,19.021-18.243,23.494-30.562l1.061-3.67c0.022-0.105,0.059-0.28,0.08-0.453c0.277-1.493-0.715-2.86-2.112-3.113
				c-0.202-0.039-0.383-0.076-0.559-0.096l-3.59-0.052c-13.286-0.162-26.121,3.773-37.105,11.377L54.606,36.325z"/>
		</g>
		<g>
			<g>
				<path fill="#36B8AF" d="M72.187,75.456l-4.92-7.109c-0.324-0.468-0.207-1.105,0.26-1.43l14.205-9.832
					c0.339-0.234,0.791-0.244,1.14-0.016c0.346,0.222,0.527,0.636,0.453,1.044l-2.178,12.021c-0.048,0.267-0.201,0.507-0.425,0.662
					l-7.105,4.919C73.149,76.038,72.51,75.921,72.187,75.456z M69.541,68.022l3.751,5.419l5.911-4.092l1.66-9.164L69.541,68.022z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#36B8AF" d="M52.164,71.833c-0.003-0.005-0.011-0.017-0.02-0.026L39.03,52.858c-0.323-0.467-0.209-1.106,0.26-1.43
					c1.863-1.29,3.814-2.028,5.647-2.141l3.525-0.577c0.392-0.059,0.783,0.108,1.009,0.432l9.832,14.206
					c0.225,0.323,0.242,0.75,0.047,1.093l-1.824,3.19c-0.931,1.704-2.221,3.185-3.735,4.282c-0.055,0.065-0.122,0.127-0.197,0.18
					C53.125,72.416,52.487,72.298,52.164,71.833z M41.327,52.566L53.22,69.749c0.998-0.851,1.856-1.914,2.512-3.119l1.514-2.645
					l-9.095-13.14l-2.989,0.481C43.912,51.407,42.598,51.839,41.327,52.566z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#36B8AF" d="M47.596,39.927l-4.913-7.097c-0.322-0.467-0.205-1.106,0.26-1.429l7.106-4.919
					c0.224-0.155,0.5-0.216,0.767-0.166L62.828,28.5c0.41,0.077,0.73,0.388,0.821,0.796c0.086,0.403-0.08,0.823-0.419,1.06
					l-14.205,9.832C48.558,40.51,47.918,40.394,47.596,39.927z M44.958,32.506l3.742,5.406l11.32-7.837l-9.151-1.661L44.958,32.506z
					"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#030405" d="M75.069,41.929c-1.687-2.436-2.32-5.425-1.78-8.41c1.133-6.179,6.859-10.144,13.035-9.021
					c2.99,0.541,5.566,2.186,7.253,4.623c1.69,2.441,2.317,5.429,1.771,8.414c-1.126,6.175-6.853,10.139-13.034,9.022
					C79.332,46.013,76.76,44.372,75.069,41.929z M91.886,30.291c-1.375-1.988-3.481-3.329-5.928-3.774
					c-5.048-0.915-9.725,2.323-10.651,7.373c-0.439,2.443,0.076,4.883,1.451,6.872c1.377,1.99,3.48,3.331,5.922,3.774
					c5.051,0.913,9.727-2.324,10.648-7.371C93.776,34.721,93.263,32.279,91.886,30.291z M78.42,39.609
					c-1.068-1.543-1.466-3.444-1.117-5.359c0.351-1.927,1.397-3.575,2.942-4.646c1.542-1.063,3.446-1.455,5.362-1.104
					c1.913,0.35,3.553,1.393,4.62,2.935s1.465,3.444,1.118,5.358c-0.348,1.912-1.386,3.558-2.922,4.627
					c-1.544,1.071-3.456,1.467-5.383,1.12C81.128,42.192,79.487,41.151,78.42,39.609z M88.542,32.602
					c-0.755-1.091-1.93-1.828-3.307-2.08c-1.374-0.253-2.734,0.021-3.823,0.774c-1.095,0.755-1.837,1.938-2.092,3.32
					c-0.495,2.748,1.341,5.399,4.09,5.901c1.385,0.255,2.75-0.026,3.841-0.786c1.09-0.753,1.826-1.929,2.071-3.307
					C89.573,35.053,89.298,33.694,88.542,32.602z"/>
			</g>
		</g>
		<g>
			<path fill="#36B8AF" d="M61.387,69.969L44.006,44.861c-0.97-1.404-0.633-3.264,0.769-4.232l7.816-5.409
				c0.466-0.324,1.106-0.208,1.43,0.26l19.671,28.42c0.323,0.466,0.208,1.106-0.26,1.429l-7.816,5.41
				C64.193,71.724,62.373,71.392,61.387,69.969z M52.917,37.495l-6.973,4.825c-0.477,0.33-0.578,0.896-0.249,1.371l17.381,25.108
				c0.335,0.485,0.885,0.585,1.371,0.25l6.971-4.826L52.917,37.495z"/>
		</g>
		<g>
			<g>
				<path fill="#36B8AF" d="M110.294,34.353L94.563,11.626c-0.188-0.271-0.23-0.617-0.12-0.929c0.108-0.308,0.362-0.548,0.679-0.64
					c6.528-1.906,12.74-2.769,18.993-2.647l3.916,0.089c0.056,0.004,0.109,0.007,0.166,0.017l0.17,0.033
					c0.132,0.024,0.26,0.052,0.388,0.069c2.586,0.481,4.248,3.026,3.781,5.667l-0.115,0.62l-1.292,3.642
					c-2.521,6.474-5.515,11.973-9.169,16.838c-0.195,0.264-0.51,0.417-0.839,0.408C110.792,34.789,110.482,34.625,110.294,34.353z
					 M97.074,11.641l14.091,20.356c3.158-4.43,5.794-9.407,8.041-15.167l1.286-3.792c0.315-1.779-0.635-3.125-2.075-3.393
					c-0.12-0.018-0.276-0.048-0.438-0.08l-0.08-0.016l-3.823-0.084C108.471,9.355,102.896,10.066,97.074,11.641z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#F9DA55" d="M19.854,71.252c-0.32-0.461-0.211-1.095,0.249-1.422l17.841-12.669c0.463-0.327,1.104-0.22,1.432,0.244
					c0.004,0.005,0.006,0.007,0.009,0.011c0.319,0.461,0.21,1.095-0.251,1.423L21.292,71.506c-0.463,0.327-1.104,0.221-1.431-0.243
					C19.857,71.258,19.856,71.255,19.854,71.252z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#F9DA55" d="M5,60.531c-0.047-0.067-0.086-0.146-0.118-0.229c-0.195-0.531,0.076-1.12,0.608-1.316l29.832-11.017
					c0.53-0.193,1.117,0.068,1.319,0.61c0.196,0.533-0.075,1.121-0.605,1.316L6.2,60.912C5.752,61.077,5.262,60.909,5,60.531z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#F9DA55" d="M33.133,101.176c-0.26-0.374-0.243-0.894,0.069-1.255l20.822-24.033
					c0.371-0.428,1.018-0.474,1.447-0.103c0.436,0.378,0.474,1.02,0.105,1.446l-20.821,24.034c-0.373,0.428-1.02,0.474-1.451,0.102
					C33.241,101.309,33.181,101.245,33.133,101.176z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#F9DA55" d="M23.807,76.962c-0.319-0.461-0.209-1.093,0.25-1.422l17.836-12.675c0.463-0.327,1.105-0.22,1.434,0.242
					c0.001,0.003,0.004,0.006,0.006,0.01c0.32,0.462,0.209,1.094-0.25,1.424L25.246,77.217c-0.463,0.327-1.104,0.22-1.432-0.244
					C23.813,76.972,23.811,76.968,23.807,76.962z"/>
			</g>
		</g>
		<g>
			<g>
				<path fill="#F9DA55" d="M27.754,82.666c-0.319-0.462-0.21-1.092,0.25-1.422l17.841-12.668c0.464-0.327,1.104-0.219,1.433,0.243
					c0.004,0.005,0.006,0.007,0.008,0.01c0.318,0.463,0.211,1.097-0.25,1.423L29.194,82.92c-0.464,0.328-1.105,0.22-1.433-0.243
					C27.76,82.674,27.758,82.671,27.754,82.666z"/>
			</g>
		</g>
	</g>
</g>
</svg>`;

export function FeatureIcon2() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg2 }}
    />
  );
}

const rawSvg3 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<line fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="13.56" y1="17.466" x2="107.194" y2="17.466"/>
<g>
	<g>
		<path fill="#030405" d="M36.255,29.888h3.509v12.454c0,5.302-2.566,7.069-6.389,7.069c-0.968,0-2.191-0.172-2.936-0.457
			l0.428-2.822c0.57,0.172,1.34,0.34,2.167,0.34c1.995,0,3.221-0.91,3.221-4.246V29.888z"/>
		<path fill="#030405" d="M60.651,39.293c0,6.442-3.904,10.12-9.205,10.12c-5.416,0-8.836-4.134-8.836-9.777
			c0-5.9,3.705-10.061,9.123-10.061C57.346,29.574,60.651,33.822,60.651,39.293z M46.315,39.579c0,3.903,1.967,7.012,5.329,7.012
			c3.394,0,5.302-3.136,5.302-7.154c0-3.619-1.796-7.042-5.302-7.042C48.167,32.396,46.315,35.617,46.315,39.579z"/>
		<path fill="#030405" d="M63.671,30.144c1.111-0.229,3.137-0.398,5.104-0.398c2.595,0,4.188,0.314,5.501,1.226
			c1.196,0.712,1.995,1.968,1.995,3.593c0,1.766-1.11,3.392-3.192,4.161v0.057c2.025,0.513,3.878,2.109,3.878,4.759
			c0,1.71-0.742,3.05-1.853,3.963c-1.368,1.197-3.619,1.797-7.126,1.797c-1.938,0-3.42-0.143-4.306-0.257V30.144H63.671z
			 M67.15,37.726h1.796c2.423,0,3.791-1.141,3.791-2.765c0-1.796-1.368-2.622-3.593-2.622c-1.025,0-1.623,0.057-1.994,0.143V37.726z
			 M67.15,46.562c0.457,0.058,1.054,0.086,1.853,0.086c2.253,0,4.247-0.854,4.247-3.221c0-2.223-1.938-3.135-4.358-3.135h-1.74
			L67.15,46.562L67.15,46.562z"/>
	</g>
</g>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="13.56" y1="58.951" x2="55.904" y2="58.951"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="13.56" y1="69.447" x2="64.888" y2="69.447"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="13.56" y1="79.443" x2="64.888" y2="79.443"/>
<g>
	<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M123.769,93.721
		c0.671,0.627,0.709,1.685,0.082,2.356l0,0c-0.626,0.674-1.683,0.709-2.354,0.084l-12.8-11.922
		c-0.676-0.627-0.711-1.684-0.086-2.354l0,0c0.628-0.677,1.686-0.714,2.354-0.085L123.769,93.721z"/>
	
		<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="104.378" y1="77.856" x2="109.252" y2="82.402"/>
	
		<circle fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="90.679" cy="65.186" r="18.973"/>
</g>
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M97.693,91.873h-81.95
	c-5.122,0-9.276-4.153-9.276-9.274V17.977c0-5.121,4.154-9.275,9.276-9.275h90.915c5.124,0,9.275,4.154,9.275,9.275V73.01"/>
</svg>`;

export function FeatureIcon3() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg3 }}
    />
  );
}

const rawSvg4 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<polygon fill="none" stroke="#000000" stroke-width="2" stroke-miterlimit="10" points="71.706,73.548 76.882,78.503 82.237,73.548 
	77.745,58.614 75.989,58.614 "/>
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M110.88,156.255"/>
<circle fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="38.714" cy="35.042" r="23.259"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="38.714" y1="35.042" x2="38.714" y2="21.631"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="38.714" y1="35.042" x2="48.374" y2="35.042"/>
<g>
	<g>
		<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M104.346,83.695
			c-1.506-15.949-13.108-28.374-27.209-28.374c-14.1,0-25.699,12.425-27.202,28.374"/>
	</g>
	<path fill="#FFFFFF" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M95.327,35.043
		c0,10.139-8.217,18.356-18.359,18.356c-10.137,0-18.352-8.217-18.352-18.356c0-10.14,8.215-18.359,18.352-18.359
		C87.11,16.684,95.327,24.903,95.327,35.043z"/>
</g>
<g>
	<path d="M31.162,40.757h1.517v5.392c0,2.295-1.11,3.061-2.764,3.061c-0.419,0-0.949-0.074-1.271-0.198l0.185-1.222
		c0.247,0.074,0.58,0.148,0.938,0.148c0.864,0,1.395-0.395,1.395-1.839V40.757z"/>
	<path d="M41.724,44.829c0,2.789-1.691,4.381-3.986,4.381c-2.345,0-3.825-1.789-3.825-4.232c0-2.555,1.604-4.355,3.949-4.355
		C40.293,40.621,41.724,42.46,41.724,44.829z M35.517,44.953c0,1.69,0.851,3.036,2.308,3.036c1.468,0,2.295-1.357,2.295-3.098
		c0-1.566-0.778-3.048-2.295-3.048C36.319,41.843,35.517,43.237,35.517,44.953z"/>
	<path d="M43.031,40.867c0.482-0.099,1.357-0.172,2.209-0.172c1.124,0,1.813,0.136,2.382,0.531c0.518,0.309,0.864,0.852,0.864,1.555
		c0,0.765-0.481,1.469-1.382,1.802v0.024c0.876,0.222,1.679,0.914,1.679,2.061c0,0.74-0.322,1.32-0.803,1.715
		c-0.593,0.518-1.567,0.778-3.084,0.778c-0.839,0-1.481-0.063-1.863-0.112v-8.183H43.031z M44.538,44.15h0.777
		c1.049,0,1.642-0.494,1.642-1.196c0-0.778-0.592-1.135-1.555-1.135c-0.444,0-0.704,0.024-0.863,0.062V44.15z M44.538,47.976
		c0.197,0.024,0.456,0.037,0.801,0.037c0.976,0,1.839-0.37,1.839-1.395c0-0.962-0.839-1.357-1.889-1.357h-0.752V47.976z"/>
</g>
</svg>`;

export function FeatureIcon4() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg4 }}
    />
  );
}

const rawSvg5 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M110.88,156.255"/>
<g>
	<path fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M118.549,97.663
		c1.341,1.252,1.416,3.364,0.164,4.707l0,0c-1.249,1.345-3.36,1.415-4.701,0.167L88.446,78.726c-1.35-1.253-1.42-3.363-0.172-4.703
		l0,0c1.254-1.352,3.366-1.426,4.703-0.17L118.549,97.663z"/>
	
		<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="80.629" y1="66.747" x2="88.274" y2="74.023"/>
	
		<circle fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="52.46" cy="40.671" r="37.895"/>
</g>
<g>
	<path d="M54.647,46.719c0,0.936-0.759,1.695-1.699,1.695l0,0c-0.937,0-1.696-0.761-1.696-1.695v-1.465
		c0-0.938,0.759-1.698,1.696-1.698l0,0c0.94,0,1.699,0.76,1.699,1.698V46.719z"/>
	<g>
		<g>
			
				<path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="
				M65.394,54.419c-0.689-7.294-5.996-12.978-12.445-12.978c-6.449,0-11.754,5.683-12.442,12.978"/>
		</g>
		
			<circle fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="52.873" cy="32.167" r="8.396"/>
	</g>
	<path d="M54.345,54.837c0,0.771-0.625,1.396-1.395,1.396l0,0c-0.771,0-1.395-0.625-1.395-1.396v-3.933
		c0-0.77,0.625-1.396,1.395-1.396l0,0c0.77,0,1.395,0.626,1.395,1.396V54.837z"/>
</g>
<polygon fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" points="52.458,7.85 
	64.323,25.163 84.454,31.098 71.655,47.731 72.233,68.711 52.458,61.679 32.683,68.711 33.262,47.731 20.462,31.098 40.594,25.163 
	"/>
</svg>`;

export function FeatureIcon5() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg5 }}
    />
  );
}

const rawSvg6 = `<?xml version="1.0" encoding="utf-8"?>
<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg version="1.1" id="Warstwa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 width="130.355px" height="104.667px" viewBox="0 0 130.355 104.667" enable-background="new 0 0 130.355 104.667"
	 xml:space="preserve">
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M116.88,158.255"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="37.796" y1="63.241" x2="89.752" y2="63.241"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="37.796" y1="73.737" x2="89.125" y2="73.737"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="37.796" y1="83.733" x2="73.46" y2="83.733"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="37.796" y1="43.833" x2="64.556" y2="43.833"/>
<line fill="none" stroke="#F9DA55" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" x1="37.796" y1="30.083" x2="64.556" y2="30.083"/>
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M39.227,14.477
	c0-2.985,2.42-5.405,5.404-5.405h57.657c2.985,0,5.404,2.42,5.404,5.405v69.341c0,2.983-2.419,5.404-5.404,5.404"/>
<path fill="none" stroke="#36B8AF" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="M97.693,89.818
	c0,2.983-2.419,5.404-5.404,5.404H34.632c-2.984,0-5.404-2.421-5.404-5.404V20.477c0-2.985,2.42-5.405,5.404-5.405h57.657
	c2.985,0,5.404,2.42,5.404,5.405V89.818z"/>
<g>
	<g>
		
			<path fill-rule="evenodd" clip-rule="evenodd" fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" d="
			M88.963,44.401c-0.396-4.198-3.449-7.468-7.16-7.468s-6.764,3.27-7.159,7.468"/>
	</g>
	
		<circle fill="none" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-miterlimit="10" cx="81.759" cy="31.597" r="4.831"/>
</g>
</svg>`;

export function FeatureIcon6() {
  return (
    <div
      className="flex justify-center items-center w-full h-[105px]"
      dangerouslySetInnerHTML={{ __html: rawSvg6 }}
    />
  );
}
