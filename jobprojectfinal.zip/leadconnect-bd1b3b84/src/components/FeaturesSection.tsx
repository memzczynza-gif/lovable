import { motion } from "framer-motion";
import {
  FeatureIcon1,
  FeatureIcon2,
  FeatureIcon3,
  FeatureIcon4,
  FeatureIcon5,
  FeatureIcon6,
} from "./FeatureIcons";

export function FeaturesSection() {
  const items = [
    {
      icon: <FeatureIcon1 />,
      title: "Wybrać zawód spójny z Tobą",
      desc: "w oparciu o swoją osobowość, umiejętności, zainteresowania, wartości",
    },
    {
      icon: <FeatureIcon2 />,
      title: "Ruszyć z miejsca",
      desc: "swoją karierę zawodową",
    },
    {
      icon: <FeatureIcon3 />,
      title: "Zmienić pracę",
      desc: "wykorzystując zasoby, które już wypracowałeś/aś",
    },
    {
      icon: <FeatureIcon4 />,
      title: "Wrócić do pracy",
      desc: "po przerwie zawodowej",
    },
    {
      icon: <FeatureIcon5 />,
      title: null,
      customNode: (
        <p className="text-sm text-[#444444] leading-relaxed">
          Rozpoznać{" "}
          <strong className="text-[#18c1c9] font-bold">
            jaka praca wykorzystuje Twoje talenty
          </strong>{" "}
          i świadomie kształtować swoją karierę
        </p>
      ),
    },
    {
      icon: <FeatureIcon6 />,
      title: null,
      customNode: (
        <p className="text-sm text-[#444444] leading-relaxed">
          Skonsultować lub napisać{" "}
          <strong className="text-[#18c1c9] font-bold">profesjonalne CV</strong> oraz przygotować
          się do <strong className="text-[#18c1c9] font-bold">rozmowy kwalifikacyjnej</strong>
        </p>
      ),
    },
  ];

  return (
    <section className="py-14 sm:py-20 bg-white overflow-hidden">
      <div className="max-w-[1240px] mx-auto px-6 sm:px-12 lg:px-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <h2 className="text-3xl sm:text-4xl lg:text-[44px] font-bold tracking-tight text-[#2d2d2d]">
            Jeśli <span className="text-[#18c1c9]">chcesz</span>
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-y-14 gap-x-10 text-center">
          {items.map((item, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.08 }}
              whileHover={{ y: -6, transition: { duration: 0.2 } }}
              className="flex flex-col items-center group cursor-pointer"
            >
              <div className="transition-transform duration-300 group-hover:scale-110">
                {item.icon}
              </div>
              <div className="mt-4 max-w-[280px]">
                {item.title ? (
                  <>
                    <h3 className="text-base font-bold text-[#18c1c9] leading-snug">
                      {item.title}
                    </h3>
                    <p className="text-sm text-[#444444] mt-1.5 leading-relaxed font-normal">
                      {item.desc}
                    </p>
                  </>
                ) : (
                  item.customNode
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
