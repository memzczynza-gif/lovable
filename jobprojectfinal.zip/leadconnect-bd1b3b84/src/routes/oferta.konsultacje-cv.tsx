import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/oferta/konsultacje-cv")({
  head: () => ({
    meta: [
      { title: "Konsultacja CV - Job Project Coaching Kariery" },
      {
        name: "description",
        content: "Dobre CV to Twoja wizytówka. Zamów profesjonalną konsultację i korektę CV.",
      },
    ],
  }),
  component: KonsultacjaCvPage,
});

export default function KonsultacjaCvPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link
              to="/oferta"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer"
            >
              Darmowa konsultacja
            </button>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center min-h-[220px] flex items-center justify-center"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <h1 className="relative z-10 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
          Konsultacja CV
        </h1>
      </section>

      {/* Text Section */}
      <section className="py-14 bg-white text-center">
        <div className="max-w-[850px] mx-auto px-6 space-y-6">
          <p className="text-base sm:text-lg text-[#333333] leading-relaxed">
            Dobre CV to Twoja wizytówka i profesjonalny sposób zaprezentowania swojej osoby.
          </p>
          <p className="text-sm sm:text-base text-[#555555] leading-relaxed">
            Pomogę Ci z sukcesem zrobić pierwsze dobre wrażenie. Doradzę jak przejść przez pierwszy
            etap rekrutacji podpowiadając co warto zmienić w Twoim obecnym CV aby oddawało ono w
            pełni Twoje atuty i odpowiadało na potrzeby rekrutacyjne.
          </p>
        </div>
      </section>

      {/* Included Card */}
      <section className="py-10 bg-gray-50/50">
        <div className="max-w-[800px] mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center text-[#111111] mb-8">
            W cenie pakietu otrzymasz:
          </h2>
          <div className="bg-white border border-[#18c1c9] rounded-2xl p-8 sm:p-10 shadow-xs space-y-6">
            <div className="flex items-start gap-4">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                alt="Check"
                className="w-5 h-5 shrink-0 mt-1"
              />
              <p className="text-sm sm:text-base font-medium text-[#222222]">
                <strong className="font-bold">30 min</strong> wstępną konsultację
                telefoniczną/on-line
              </p>
            </div>
            <div className="flex items-start gap-4">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                alt="Check"
                className="w-5 h-5 shrink-0 mt-1"
              />
              <p className="text-sm sm:text-base font-medium text-[#222222]">
                60 min konsultację osobistą lub on-line dotyczącą profesjonalnej korekty Twojego
                aktualnego CV. Otrzymasz wskazówki co i jak poprawić merytorycznie i wizualnie aby
                wyróżnić się wśród konkurentów i nie zostać pominiętym przez rekrutera
              </p>
            </div>
            <div className="pt-4 text-center">
              <button
                onClick={() => openBookingModal("consultation")}
                className="bg-[#f5dc62] hover:bg-[#ebd04d] text-black font-bold uppercase text-sm py-3.5 px-8 rounded-full transition-colors cursor-pointer"
              >
                Umów się na spotkanie
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Pamiętaj */}
      <section className="py-14 bg-white text-center">
        <div className="max-w-[750px] mx-auto px-6 space-y-4">
          <h3 className="text-xl sm:text-2xl font-bold text-[#111111]">Pamiętaj:</h3>
          <p className="text-sm sm:text-base text-[#444444] leading-relaxed">
            7/10 CV w ogóle nie jest czytana ze względu na nieciekawą formę oraz nieodpowiednią
            treść. Dobre CV to podstawa otwierająca drzwi do dalszych możliwości.
          </p>
        </div>
      </section>

      {/* Bottom Banners */}
      <section className="py-12 bg-white text-center border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-6 space-y-5">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#111111]">
            Gotowa/y, żeby Twój profil zaczął pracować na Ciebie?
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na bezpłatną konsultację!
            </button>
          </div>
        </div>
      </section>

      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>
          <div className="hidden md:block"></div>
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
