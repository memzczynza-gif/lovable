import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/quizy/")({
  head: () => ({
    meta: [
      {
        title: "Quizy | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Interaktywne quizy kariery od Job Project. Sprawdź swój potencjał zawodowy, rozpoznaj swoje atuty i odkryj kierunek rozwoju dzięki krótkim testom online.",
      },
      { property: "og:title", content: "Quizy - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Interaktywne quizy kariery. Sprawdź swój potencjał zawodowy i odkryj kierunek rozwoju.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: QuizyPage,
});

export default function QuizyPage() {
  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link
              to="/"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="inline-block transition-opacity hover:opacity-90"
            >
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>

          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link
              to="/"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>
            <Link to="/quizy" className="text-[#18c1c9] font-bold transition-colors cursor-pointer">
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <Link
              to="/kontakt"
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </Link>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link
            to="/"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <Link to="/oferta" className="whitespace-nowrap hover:text-[#18c1c9]">
            Oferta
          </Link>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>
          <Link to="/quizy" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* Hero Header Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-16 text-center min-h-[200px] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 px-6 max-w-4xl mx-auto"
        >
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight drop-shadow-md">
            Quizy
          </h1>
          <p className="mt-4 text-sm sm:text-base text-white/90 max-w-2xl mx-auto leading-relaxed">
            Krótkie, interaktywne testy, które pomagają rozpoznać Twój potencjał zawodowy i odkryć
            kierunek rozwoju kariery.
          </p>
        </motion.div>
      </section>

      {/* Intro + Quiz cards */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-[1100px] mx-auto px-6 space-y-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center space-y-4"
          >
            <h2 className="text-2xl sm:text-3xl font-bold text-[#111111]">
              Interaktywne quizy kariery
            </h2>
            <p className="text-sm sm:text-base text-[#444444] leading-relaxed font-normal max-w-2xl mx-auto">
              Wybierz quiz i w kilka minut sprawdź, na jakim etapie kariery się znajdujesz oraz jaka
              strategia rozwoju przyniesie Ci najlepsze efekty.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Quiz 1 Active Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="border border-[#18c1c9]/40 rounded-2xl p-8 bg-[#F7F5E8]/60 hover:shadow-lg transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-[#18c1c9]/20 flex items-center justify-center mb-4 text-[#18c1c9]">
                  <svg
                    className="w-6 h-6"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                </div>
                <div className="inline-block px-3 py-1 bg-[#18c1c9]/15 text-[#18c1c9] text-xs font-bold rounded-full mb-3 uppercase tracking-wider">
                  Dostępny teraz
                </div>
                <h3 className="text-xl font-bold text-[#111111] mb-2">Ścieżka A czy B?</h3>
                <p className="text-sm text-[#444444] leading-relaxed mb-6">
                  7 pytań, które pomogą Ci odkryć, czy potrzebujesz narzędzi do szukania pracy
                  (Ścieżka B), czy wsparcia w zmianie kierunku zawodowego (Ścieżka A).
                </p>
              </div>

              <Link
                to="/quizy/sciezka-a-czy-b"
                className="w-full bg-[#18c1c9] hover:bg-[#15adb4] text-white text-center font-bold text-sm py-3 px-6 rounded-xl transition-all shadow-sm"
              >
                Rozpocznij quiz →
              </Link>
            </motion.div>

            {/* Quiz 2 Active Card */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="border border-[#18c1c9]/40 rounded-2xl p-8 bg-[#F7F5E8]/60 hover:shadow-lg transition-all flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-[#18c1c9]/20 flex items-center justify-center mb-4 text-[#18c1c9]">
                  <svg
                    className="w-6 h-6"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M9 20l-5.45-2.73a1 1 0 0 1-.55-.9V4.62a1 1 0 0 1 1.45-.9L9 6" />
                    <path d="M9 20V6" />
                    <path d="M15 4l5.45 2.73a1 1 0 0 1 .55.9v11.75a1 1 0 0 1-1.45.9L15 18" />
                    <path d="M15 18V4" />
                    <path d="M9 6l6-2" />
                    <path d="M9 20l6-2" />
                  </svg>
                </div>
                <div className="inline-block px-3 py-1 bg-[#18c1c9]/15 text-[#18c1c9] text-xs font-bold rounded-full mb-3 uppercase tracking-wider">
                  Dostępny teraz
                </div>
                <h3 className="text-xl font-bold text-[#111111] mb-2">Mapa Kariery</h3>
                <p className="text-sm text-[#444444] leading-relaxed mb-6">
                  Interaktywna gra kariery, która mapuje Twój profil zawodowy i pokazuje dopasowane
                  ścieżki rozwoju. Odkryj swoje mocne strony i obszary do rozwoju.
                </p>
              </div>

              <Link
                to="/quizy/mapa-kariery"
                className="w-full bg-[#18c1c9] hover:bg-[#15adb4] text-white text-center font-bold text-sm py-3 px-6 rounded-xl transition-all shadow-sm"
              >
                Rozpocznij quiz →
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          <div className="hidden md:block"></div>

          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
    </div>
  );
}
