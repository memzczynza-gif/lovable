import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/oferta/")({
  head: () => ({
    meta: [
      { title: "Moja Oferta - Job Project Coaching Kariery" },
      {
        name: "description",
        content:
          "Poznaj moją ofertę coachingu kariery: sesje indywidualne, program Kariera idealnie dobrana do Ciebie, konsultacja CV, przygotowanie do rozmowy rekrutacyjnej oraz profil LinkedIn.",
      },
      { property: "og:title", content: "Moja Oferta - Job Project Coaching Kariery" },
      { property: "og:type", content: "website" },
    ],
  }),
  component: OfertaPage,
});

export default function OfertaPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  const offerCards = [
    {
      title: "Sesje indywidualne",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af5f4800de619af1941ec3.jpeg",
      link: "/oferta/sesje-indywidualne",
    },
    {
      title: "Kariera idealnie dobrana do Ciebie Program coachingowo - szkoleniowy",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af610e8fd7841d314b1458.jpeg",
      link: "/oferta/kariera",
    },
    {
      title: "Konsultacja CV",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg",
      link: "/oferta/konsultacje-cv",
    },
    {
      title: "Przygotowanie do rozmowy rekrutacyjnej",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af62a32aa5a54044509685.jpeg",
      link: "/oferta/rozmowa-rekrutacyjna",
    },
    {
      title: "Audyt profilu Linkedin",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6a07051eff331dd87923d405.jpg",
      link: "/oferta/linkedin",
    },
    {
      title: "Przygotowanie profilu Linkedin",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6a070520ff331dd87923d464.jpg",
      link: "/oferta/linkedin",
    },
  ];

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>

          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link
              to="/oferta"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile Horizontal Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <Link to="/oferta" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Oferta
          </Link>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* Hero Header Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center min-h-[220px] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 px-6 max-w-4xl mx-auto"
        >
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight drop-shadow-md">
            Moja oferta
          </h1>
        </motion.div>
      </section>

      {/* Offer Cards Grid - 2 per row on desktop */}
      <section className="py-16 sm:py-20 bg-white">
        <div className="max-w-[1140px] mx-auto px-6 sm:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-10 gap-y-12">
            {offerCards.map((card, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.08 }}
                className="flex flex-col items-center group cursor-pointer text-center"
              >
                <Link
                  to={card.link}
                  className="block w-full overflow-hidden rounded-xl shadow-xs group-hover:shadow-md transition-all"
                >
                  <div className="aspect-[16/10] w-full overflow-hidden bg-gray-100">
                    <img
                      src={card.img}
                      alt={card.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                </Link>

                <div className="mt-5 max-w-[480px]">
                  <Link
                    to={card.link}
                    className="inline-block bg-[#18c1c9] hover:bg-[#15adb4] text-white font-semibold text-sm sm:text-base px-6 py-3 rounded-full transition-all shadow-xs group-hover:scale-[1.02] leading-snug"
                  >
                    {card.title}
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Gotowa/y, żeby Twój profil zaczął pracować na Ciebie? */}
      <section className="py-12 bg-white text-center border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-6 space-y-5">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#111111]">
            Gotowa/y, żeby Twój profil zaczął pracować na Ciebie?
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block"
            >
              Umów się na bezpłatną konsultację!
            </button>
          </div>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          <div className="hidden md:block"></div>

          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
