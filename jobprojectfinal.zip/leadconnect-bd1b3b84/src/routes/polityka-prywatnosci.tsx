import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/polityka-prywatnosci")({
  head: () => ({
    meta: [
      {
        title:
          "Polityka prywatności | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Polityka Prywatności (Privacy Policy) serwisu Job Project - Magdalena Chmielecka-Lisiecka. Informacje o przetwarzaniu danych osobowych (RODO).",
      },
      { property: "og:title", content: "Polityka prywatności - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Polityka Prywatności (Privacy Policy) serwisu Job Project - Magdalena Chmielecka-Lisiecka.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PolitykaPrywatnosciPage,
});

export default function PolitykaPrywatnosciPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative flex flex-col justify-between">
      {/* 1. Header with exact navigation matching Job Project style */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* 2. Main Privacy Policy Content Section */}
      <main className="flex-1 py-12 sm:py-16 bg-white">
        <div className="max-w-[1140px] mx-auto px-6 sm:px-12 text-[#222222]">
          {/* Main Title */}
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold text-[#111111] mb-6 tracking-tight">
            Polityka prywatności
          </h1>

          <p className="font-bold text-base sm:text-[17px] text-[#222222] mb-6">
            Polityka Prywatności (Privacy Policy)
          </p>

          {/* Points 1 - 8 */}
          <div className="space-y-4 text-xs sm:text-[13.5px] leading-relaxed text-[#555555]">
            <p>
              <strong className="font-bold text-[#111111]">1. Administrator danych</strong>{" "}
              Administratorem Twoich danych osobowych jest{" "}
              <strong className="italic text-[#667085]">Magdalena Chmielecka - Lisiecka</strong>, w
              ramach JobProject.
            </p>

            <div>
              <p>
                <strong className="font-bold text-[#111111]">2. Zakres danych</strong> Przetwarzam
                dane podane dobrowolnie przez klienta, takie jak:
              </p>
              <ul className="list-disc pl-6 mt-1.5 space-y-1">
                <li>imię, adres e-mail, numer telefonu,</li>
                <li>dane przekazane w wiadomości (np. zdjęcia, opis sytuacji),</li>
                <li>dane niezbędne do realizacji usługi.</li>
              </ul>
            </div>

            <div>
              <p>
                <strong className="font-bold text-[#111111]">3. Cel przetwarzania danych</strong>{" "}
                Dane przetwarzane są w celu:
              </p>
              <ul className="list-disc pl-6 mt-1.5 space-y-1">
                <li>realizacji usług,</li>
                <li>kontaktu z klientem,</li>
                <li>prowadzenia dokumentacji księgowej (jeśli dotyczy).</li>
              </ul>
            </div>

            <p>
              <strong className="font-bold text-[#111111]">4. Podstawa prawna</strong> Podstawą
              przetwarzania danych jest art. 6 ust. 1 lit. b RODO (realizacja umowy) oraz lit. f
              (uzasadniony interes administratora).
            </p>

            <p>
              <strong className="font-bold text-[#111111]">5. Czas przechowywania danych</strong>{" "}
              Dane przechowywane są przez okres niezbędny do realizacji usług oraz rozliczeń
              podatkowych.
            </p>

            <div>
              <p>
                <strong className="font-bold text-[#111111]">
                  6. Prawa osoby, której dane dotyczą
                </strong>{" "}
                Masz prawo do:
              </p>
              <ul className="list-disc pl-6 mt-1.5 space-y-1">
                <li>dostępu do danych,</li>
                <li>ich sprostowania,</li>
                <li>usunięcia,</li>
                <li>ograniczenia przetwarzania,</li>
                <li>wniesienia sprzeciwu.</li>
              </ul>
            </div>

            <p>
              <strong className="font-bold text-[#111111]">7. Przekazywanie danych</strong> Dane nie
              są przekazywane osobom trzecim ani poza EOG, z wyjątkiem narzędzi do obsługi
              wiadomości i formularzy (np. Gmail, Typeform) – zawsze zgodnie z RODO.
            </p>

            <p>
              <strong className="font-bold text-[#111111]">8. Kontakt</strong> W sprawach
              dotyczących danych osobowych można kontaktować się mailowo.
            </p>
          </div>
        </div>
      </main>

      {/* 3. Bottom CTA Banner (section-4XzGrtRy52) - Exact Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
