import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/quizy")({
  component: QuizyLayout,
});

export default function QuizyLayout() {
  return <Outlet />;
}
