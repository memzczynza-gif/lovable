import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/referencje")({
  head: () => ({
    meta: [
      {
        title: "Referencje | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Przeczytaj opinie i referencje klientów Job Project. Poznaj historie osób, które z sukcesem zmieniły pracę i zbudowały satysfakcjonującą karierę.",
      },
      { property: "og:title", content: "Referencje - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Przeczytaj opinie i referencje klientów Job Project. Poznaj historie osób, które z sukcesem zmieniły pracę.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ReferencjePage,
});

interface Testimonial {
  id: number;
  name: string;
  role: string;
  avatar: string;
  content: string;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Monika",
    role: "Deputy Store Manager",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Bardzo ciepła i wrażliwa osoba, jednocześnie konkretna i bardzo profesjonalna. Motywuje, podpowiada i wspiera w działaniu, daje pewność wyboru i zmienia niemożliwe w oczywiste. Zdecydowanie polecam. Pani Magdaleno, bardzo dziękuję!",
  },
  {
    id: 2,
    name: "Ewelina",
    role: "Sprzedawca",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Świetny specjalista, znający się na swojej pracy 🙂 Dzięki 3 spotkaniom z Panią Magdą, ponownie odzyskałam motywację do działania, poznałam swoje mocne i słabe strony oraz przygotowałam świetne cv, umożliwiajace zdobycie satysfakcjonującej pracy. Dziękuję jeszcze raz Pani Magdo za pomoc i cenne rady 😉 Zdecydowanie polecam !!!",
  },
  {
    id: 3,
    name: "Ania",
    role: "Farmaceuta",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Poszłam na jedno spotkanie które było objawieniem:) zastanawiałam się nad zmiana branży (całkowita zmiana) i szybko dzięki ogromniej wiedzy i doświadczeniu pani Magdy dotarłyśmy do odpowiedzi:) dziękuję",
  },
  {
    id: 4,
    name: "Marcin",
    role: "Fotograf",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Magda w jakiś magiczny sposób pomaga odnaleźć w sobie niewyczerpalne pokłady energii pochodzącej z jasnej strony mocy 🙂 Dziękuję za wsparcie oraz motywację do wyznaczania i osiągania celów. Zdecydowanie polecam coaching u Magdy – im wcześniej, tym lepiej.",
  },
  {
    id: 5,
    name: "Anna",
    role: "Specjalista ds. Obsługi Klienta, aktualnie Księgowa",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "“Zmieniłam z sukcesem pracę po więcej niż 10 latach i robię teraz to, co daje mi satysfakcję!! Wskazówki i prowadzenie coachingu bardzo pomocne i niezwykle użyteczne. Polecam pakiet sesji coachingowo-konsultingowych z Magdą. Mogłabym pisać i pisać… ale każdy zainteresowany profesjonalnym coachingiem niech sam sprawdzi jak coaching z Magdą wspaniale działa. Tak, mega, mega, mega mocno polecam!!!”",
  },
  {
    id: 6,
    name: "Renata",
    role: "Specjalista ds. Operacji B2P",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Praca z Magdą to czysta przyjemność. Jej profesjonalizm i niezwykle ciepłe usposobienie sprawiły, że trudny czas był bardziej kolorowy. Znakomite przygotowanie do rozmów rekrutacyjnych i ogromna pomoc w redagowaniu dokumentów zaowocowały w znalezieniu nowej pracy po 4,5 miesiącach. Dziękuję Magdo!",
  },
  {
    id: 7,
    name: "Magda",
    role: "Specjalista ds. Obsługi Klienta",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Magda jest osobą stworzoną do pracy z ludźmi, którzy znaleźli się na życiowym zakręcie bez pracy i wiary we własne możliwości. Jako wieloletni, były już pracownik międzynarodowej korporacji miałam przyjemność przejść ten trudny czas prawie bezboleśnie dzięki motywacji, wsparciu, zaangażowaniu i serdeczności, którą Magda obdarzała mnie podczas każdego kontaktu. Najlepszym dowodem jej pracy jest mój sukces w postaci zatrudnienia a także doskonałe przygotowanie do rozmów kwalifikacyjnych, które wielokrotnie było zauważane przez pracodawców i bardzo szybko poskutkowało znalezieniem wymarzonej pracy. Polecam każdemu szukającemu pracy współpracę z Magda, gdyż wskazówki i rady których udziela gwarantują nie tylko szybkie zatrudnienie, ale również podniesienie poczucia własnej wartości, które w tym trudnym czasie bywa mocno zaniżone.",
  },
  {
    id: 8,
    name: "Kasia",
    role: "Administrator przyszły Health & Nutrition Specialist",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Magda jest bardzo profesjonalna, ale też i ciepła, cierpliwa i wyrozumiała. Zgłosiłam się do niej w momencie dużego zagubienia zawodowego, przemęczenia wkładaniem energii w coś kompletnie wypalającego. Program coachingowo-szkoleniowy okazał się bardzo „oczyszczający”. Każde spotkanie on-line kierowało moje myśli na właściwe tory i pomogło uporządkować to, co wydawało się wielobiegunowym bezsensownym bałaganem. W rezultacie wiem po jaki nowy zawód sięgnę i wiem jak krok po kroku, to zrobię. Magda również doskonale motywuje i wspiera w działaniu. Dziękuję Magdo i gorąco polecam!",
  },
  {
    id: 9,
    name: "Aleksandra",
    role: "Specjalista ds. księgowości aktualnie Specjalista ds. procesów",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "I co teraz? Jak wrócić do pracy po przerwie? Te pytania krążyły po mojej głowie już od kilku miesięcy. Po urodzeniu dziecka czułam, że jestem bardzo szczęśliwa. Nadal jestem ale od kiedy mój skarb skończył 3 lata i szykujemy się do przedszkola czuję i mam ochotę wrócić do pracy. Zdecydowałam się na program coachingowo-szkoleniowy z testem psychometrycznym i rozplanowaniem działania, ponieważ lubię działać konkretnie i z sensem. To był strzał w dziesiątkę!! Polecam każdemu kto miał przerwę zawodową albo chce poznać siebie lepiej i tą wiedzę efektywnie wykorzystać w nowej pracy!!",
  },
  {
    id: 10,
    name: "Szymon",
    role: "Key Account Manager",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Doceniam profesjonalizm z serdecznym podejściem do człowieka w biznesie. Do skorzystania z sesji z Magdą pokierowała mnie potrzeba zmiany i nurtujące poczucie, że tu gdzie jestem już nie chcę dłużej być. To wiedziałem na pewno ale nie miałem pojęcia gdzie indziej byłoby wystarczająco dobrze. Spotkania indywidualne pozwoliły mi zrobić dokładny przegląd moich zasobów, dostrzeć ich wartość i wygererować realne możliwości ich wykorzystania. To bardzo budująca świadomość, że nie trzeba zaczynać wszystkiego „od nowa”, wystarczy w towarzystwie specjalisty „zrobić transfer” swoich kompetencji w nowy ekscytujący obszar zawodowy. Polecam.",
  },
  {
    id: 11,
    name: "Agnieszka",
    role: "obecnie Specjalista ds. Usług zadowolona ze zrealizowanej zmiany zawodowej",
    avatar:
      "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68b5f5c0acd791b20e2290b5.jpeg",
    content:
      "Magda – to pełen profesjonalizmu coach i konsultant a jednocześnie miła i pełna ciepła osoba. Wspiera w każdym momencie procesu, motywuje i pokazuje kierunki do działania. Wydobywa z człowieka ukryte kompetencje oraz wzmacnia te już posiadane – wskazuje jak i gdzie je wykorzystać. Praca z Magdą to czysta przyjemność i poczucie, że osiągnie się coś co na początku było tylko mglistym marzeniem. Polecam Magdę jako coacha kariery.",
  },
];

export default function ReferencjePage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );
  const [expandedIds, setExpandedIds] = useState<Record<number, boolean>>({});
  const [activePageIndex, setActivePageIndex] = useState(2); // default slide around Anna/Renata as seen in screenshot

  const itemsPerPage = 2;
  const totalPages = Math.ceil(testimonials.length / itemsPerPage);

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  const toggleExpand = (id: number) => {
    setExpandedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const currentItems = testimonials.slice(
    activePageIndex * itemsPerPage,
    activePageIndex * itemsPerPage + itemsPerPage,
  );

  const handlePrev = () => {
    setActivePageIndex((prev) => (prev > 0 ? prev - 1 : totalPages - 1));
  };

  const handleNext = () => {
    setActivePageIndex((prev) => (prev < totalPages - 1 ? prev + 1 : 0));
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header with exact navigation matching original layout */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <a
            href="https://jobproject.com.pl/oferta"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Oferta
          </a>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Page Header Banner (section-kHdT_7Ji9) - "Referencje" */}
      <section className="relative w-full bg-[#1A3326] py-16 sm:py-[72px] text-center text-white overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-overlay"
          style={{
            backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold tracking-tight text-white leading-tight">
            Referencje
          </h1>
        </div>
      </section>

      {/* 3. Testimonials Carousel Section (section-nguvXjPxF0) */}
      <section className="py-14 sm:py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-8 relative">
          {/* Carousel Slider Controls Container */}
          <div className="relative flex items-center">
            {/* Prev Arrow */}
            <button
              onClick={handlePrev}
              aria-label="Poprzedni"
              className="absolute -left-4 sm:-left-6 z-10 p-2 text-gray-700 hover:text-[#18c1c9] transition-colors cursor-pointer bg-white/80 rounded-full shadow-xs"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>

            {/* Cards Grid (2 per slide on desktop, 1 on mobile) */}
            <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 px-4 sm:px-6">
              {currentItems.map((item) => {
                const isLong = item.content.length > 180;
                const isExpanded = expandedIds[item.id];
                const displayedText =
                  isLong && !isExpanded ? item.content.slice(0, 180) + "..." : item.content;

                return (
                  <div
                    key={item.id}
                    className="bg-white border border-[#e5e7eb] rounded-xl p-6 sm:p-8 flex flex-col justify-between shadow-[0_2px_8px_rgba(0,0,0,0.04)] hover:shadow-md transition-shadow min-h-[260px]"
                  >
                    <div>
                      {/* 5 Yellow Stars */}
                      <div className="flex items-center gap-1 text-[#fbbf24] text-lg mb-4">
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                        <span>★</span>
                      </div>

                      {/* Content Text */}
                      <p className="text-xs sm:text-[13.5px] italic text-[#4b5563] leading-[1.7] font-normal mb-3">
                        {displayedText}
                      </p>

                      {/* Read More button */}
                      {isLong && (
                        <button
                          onClick={() => toggleExpand(item.id)}
                          className="text-xs text-[#374151] font-semibold hover:text-[#18c1c9] cursor-pointer mb-4 inline-block"
                        >
                          {isExpanded ? "Show less" : "Read more"}
                        </button>
                      )}
                    </div>

                    {/* Reviewer Profile Footer */}
                    <div className="flex items-center gap-3 pt-4 border-t border-gray-100/80 mt-2">
                      <img
                        src={item.avatar}
                        alt={`${item.name} - ${item.role}`}
                        className="w-10 h-10 sm:w-11 sm:h-11 rounded-full object-cover shrink-0 bg-gray-200"
                      />
                      <div>
                        <h4 className="text-xs sm:text-sm font-semibold text-[#1f2937] leading-tight">
                          {item.name} - {item.role}
                        </h4>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Next Arrow */}
            <button
              onClick={handleNext}
              aria-label="Następny"
              className="absolute -right-4 sm:-right-6 z-10 p-2 text-gray-700 hover:text-[#18c1c9] transition-colors cursor-pointer bg-white/80 rounded-full shadow-xs"
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.5"
                viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          </div>

          {/* Carousel Pagination Dots */}
          <div className="flex items-center justify-center gap-2 mt-10">
            {Array.from({ length: totalPages }).map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActivePageIndex(idx)}
                aria-label={`Strona ${idx + 1}`}
                className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                  activePageIndex === idx ? "bg-[#18c1c9] w-6" : "bg-gray-300 hover:bg-gray-400"
                }`}
              />
            ))}
          </div>

          {/* "Więcej referecji znajdziesz na stronie" section */}
          <div className="mt-16 text-center space-y-6">
            <h2 className="text-lg sm:text-xl font-bold text-[#111111]">
              Więcej referecji znajdziesz na stronie
            </h2>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <a
                href="https://dobrycoach.pl/coach/magdalena-chmielecka-lisiecka"
                target="_blank"
                rel="noreferrer noopener"
                className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-bold text-xs uppercase px-7 py-3 transition-colors cursor-pointer rounded-xs tracking-wider inline-block shadow-xs"
              >
                DOBRYCOACH.pl
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                className="bg-[#1d90f5] hover:bg-[#157cdb] text-white font-bold text-xs uppercase px-7 py-3 transition-colors cursor-pointer rounded-xs tracking-wider inline-block shadow-xs"
              >
                LINKEDIN.com
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Bottom CTA Banner (section-4XzGrtRy52) - Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 5. Footer (section-LFkwfhkPm3) */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Left Column: Moje produkty */}
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          {/* Middle Spacer */}
          <div className="hidden md:block"></div>

          {/* Right Column: Teal box with legal copyright */}
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
