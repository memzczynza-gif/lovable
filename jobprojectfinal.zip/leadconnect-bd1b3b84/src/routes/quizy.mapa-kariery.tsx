import { createFileRoute, Link } from "@tanstack/react-router";
import quizMapaHtml from "./quiz-mapa-kariery.html?raw";

export const Route = createFileRoute("/quizy/mapa-kariery")({
  head: () => ({
    meta: [
      {
        title: "Quiz: Mapa Kariery | Job Project - Coaching Kariery",
      },
      {
        name: "description",
        content:
          "Interaktywna gra kariery, która mapuje Twój profil zawodowy i pokazuje dopasowane ścieżki rozwoju. Quiz od Job Project.",
      },
      { property: "og:title", content: "Quiz: Mapa Kariery - Job Project" },
      {
        property: "og:description",
        content:
          "Interaktywna gra kariery, która mapuje Twój profil zawodowy i pokazuje dopasowane ścieżki rozwoju.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: QuizMapaPage,
});

export default function QuizMapaPage() {
  return (
    <div className="min-h-screen bg-[#f9f6f0] font-['Manrope',sans-serif]">
      {/* Navigation Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <Link to="/" className="inline-block transition-opacity hover:opacity-90">
            <img
              src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
              alt="Job Project"
              className="w-[125px] sm:w-[145px] h-auto object-contain"
            />
          </Link>
          <div className="flex items-center gap-4">
            <Link
              to="/quizy"
              className="text-xs sm:text-sm font-semibold text-[#18c1c9] hover:underline"
            >
              ← Powrót do Quizów
            </Link>
          </div>
        </div>
      </header>

      {/* Embedded Interactive Quiz */}
      <main className="py-4 px-2 sm:px-4 max-w-[1200px] mx-auto">
        <iframe
          srcDoc={quizMapaHtml}
          className="w-full min-h-[900px] h-[95vh] border-0 rounded-xl bg-transparent"
          title="Quiz: Mapa Kariery"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
      </main>
    </div>
  );
}
