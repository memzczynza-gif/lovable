import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { FeaturesSection } from "@/components/FeaturesSection";
import { CountersSection } from "@/components/CountersSection";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      {
        title: "Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Pomagam rozpoznać potencjał zawodowy, zaplanować rozwój i karierę idealnie dobraną do Ciebie. Towarzyszę w realizacji zmiany zawodowej.",
      },
      { property: "og:title", content: "Job Project - Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Pomagam rozpoznać potencjał zawodowy, zaplanować rozwój i karierę idealnie dobraną do Ciebie. Towarzyszę w realizacji zmiany zawodowej.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

export default function Index() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header with exact navigation items: Home, O Mnie, Oferta, Zespół, Referencje, Blog, Podręczniki, Grupa Mastermind, Cart icon, Button, Socials */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link
              to="/"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="inline-block transition-opacity hover:opacity-90"
            >
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link
              to="/"
              onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link
            to="/"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <Link to="/oferta" className="whitespace-nowrap hover:text-[#18c1c9]">
            Oferta
          </Link>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Hero Section (section-lJxOyXjTYl) - Exact hero photo background: 68acb0daa7e5980ec684e15a.jpeg */}
      <section
        className="relative w-full bg-[#F7F5E8] bg-cover bg-center min-h-[500px] lg:min-h-[580px] flex items-center overflow-hidden"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg')`,
        }}
      >
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 lg:px-20 w-full py-16 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="w-full lg:w-[48%] space-y-6 text-white text-left"
          >
            <motion.h1
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
              className="text-3xl sm:text-4xl lg:text-[46px] font-extrabold tracking-tight uppercase leading-[1.15] text-white"
            >
              COACHING KARIERY
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="text-sm sm:text-base lg:text-[17px] text-white/95 leading-relaxed font-normal max-w-xl"
            >
              Pomagam rozpoznać potencjał zawodowy, zaplanować rozwój i karierę idealnie dobraną do
              Ciebie. Towarzyszę w realizacji zmiany zawodowej.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.6 }}
              className="pt-2"
            >
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0 10px 25px -5px rgba(24, 193, 201, 0.5)" }}
                whileTap={{ scale: 0.97 }}
                onClick={() => openBookingModal("offer")}
                className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer shadow-none inline-block tracking-normal"
              >
                Moja oferta
              </motion.button>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* 3. Nazywam się Magdalena Chmielecka-Lisiecka (section-bz2j1HkWvX) */}
      <section className="py-14 sm:py-16 bg-white text-center overflow-hidden">
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-50px" }}
          transition={{ duration: 0.7 }}
          className="max-w-[900px] mx-auto px-6 space-y-6"
        >
          <h2 className="text-2xl sm:text-3xl lg:text-[32px] font-bold text-[#111111] leading-snug">
            Nazywam się Magdalena Chmielecka-Lisiecka
          </h2>
          <p className="text-sm sm:text-[15px] lg:text-base text-[#444444] leading-relaxed font-normal">
            Jestem coachem i trenerką kariery, absolwentką Career Coaching w Dublin Institute of
            Technology. Głęboko wierzę i mam na to dowody, że każdy/a z nas może mieć
            satysfakcjonującą pracę wybraną w oparciu o osobisty potencjał, własne predyspozycje,
            umiejętności, wiedzę i doświadczenie. Specjalizuję się w pracy z osobami, które chcą
            zrealizować zmianę zawodową lub świadomie zaplanować swoją karierę i sięgać po pracę,
            która daje radość i satysfakcję. Prywatnie jestem szczęśliwą kobietą, żoną, mamą
            wspaniałej dwójki dzieci i miłośniczką zrównoważonego życia.
          </p>
          <div className="pt-2">
            <Link
              to="/o-mnie"
              className="text-[#18c1c9] hover:text-[#15adb4] font-medium text-base hover:underline transition-all cursor-pointer inline-block"
            >
              Więcej o mnie
            </Link>
          </div>
        </motion.div>
      </section>

      {/* 4. Jeśli chcesz Section - Animated component */}
      <FeaturesSection />

      {/* 5. Consultation Banner (section-Bude-gQjGJ) - Exact image: 68adfb45150dd37caddfb76a.jpeg */}
      <section className="py-6 bg-white">
        <div className="max-w-[1240px] mx-auto px-4 sm:px-8">
          <div
            className="relative w-full rounded-none bg-cover bg-center min-h-[360px] flex items-center justify-end overflow-hidden"
            style={{
              backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68adfb45150dd37caddfb76a.jpeg')`,
            }}
          >
            {/* Dark Right Box: background: rgba(0, 0, 0, 0.70) */}
            <div className="w-full lg:w-[42%] bg-[#000000b3] text-white p-8 sm:p-12 m-4 sm:m-8 text-center space-y-6">
              <h2 className="text-xl sm:text-2xl font-bold leading-snug text-white">
                Zapraszam, umów się na bezpłatną konsultację
              </h2>
              <div>
                <button
                  onClick={() => openBookingModal("consultation")}
                  className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
                >
                  Umów się na spotkanie
                </button>
              </div>
              <p className="text-xs sm:text-sm text-gray-200 leading-relaxed font-normal">
                A może bliska Ci osoba jest w podobnej sytuacji i chcesz jej pomóc? Zrób Jej/Jemu
                prezent!
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Dlaczego sama zmieniłam zawód i lubię to co robię? (section-w_tvAZJ5z) */}
      <section className="py-16 sm:py-20 bg-white overflow-hidden">
        <div className="max-w-[950px] mx-auto px-6">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-2xl sm:text-3xl font-bold text-center text-[#111111] mb-12 sm:mb-16"
          >
            Dlaczego sama zmieniłam zawód i lubię to co robię?
          </motion.h2>

          <div className="space-y-8 sm:space-y-10">
            {/* Point 1 */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="flex items-start gap-6 sm:gap-8"
            >
              <div className="shrink-0 pt-1">
                <img
                  src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                  alt="Check"
                  className="w-6 h-6 object-contain"
                />
              </div>
              <p className="text-sm sm:text-[15px] lg:text-base text-[#333333] leading-relaxed">
                Wiem, że zawód może być spójnie dobrany do Twoich naturalnych atutów, predyspozycji
                i aspiracji. Spędzając przynajmniej ⅓ życia w pracy, sądzę, że warto aby była ona
                dla nas satysfakcjonująca
              </p>
            </motion.div>

            {/* Point 2 */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="flex items-start gap-6 sm:gap-8"
            >
              <div className="shrink-0 pt-1">
                <img
                  src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                  alt="Check"
                  className="w-6 h-6 object-contain"
                />
              </div>
              <p className="text-sm sm:text-[15px] lg:text-base text-[#333333] leading-relaxed">
                Uważam, że na zmianę nigdy nie jest za późno. Nowa praca lub zawód to projekt, do
                którego możesz przygotować się tak aby z poczuciem sensu i pewnością siebie tę
                zmianę zrealizować. Nie zawsze musi oznaczać to rewolucję… mam Klientów, którzy
                zdecydowali się wykorzystać posiadane zasoby przenosząc je w nowy i bardziej
                satysfakcjonujący obszar
              </p>
            </motion.div>

            {/* Point 3 */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex items-start gap-6 sm:gap-8"
            >
              <div className="shrink-0 pt-1">
                <img
                  src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                  alt="Check"
                  className="w-6 h-6 object-contain"
                />
              </div>
              <p className="text-sm sm:text-[15px] lg:text-base text-[#333333] leading-relaxed">
                Chcę aby ludzie realizowali się zawodowo. Dużą satysfakcję sprawiają mi osiągający
                swoje cele Klienci
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* 7. Bonus dla Ciebie już teraz! (Banner: col-RNu5kYQp2a - 50% width on right in original) */}
      <section className="py-6 bg-white">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 lg:px-20 flex justify-end">
          <div className="w-full lg:w-[50%] bg-[#18c1c9] text-white p-8 sm:p-10 space-y-5">
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
              Bonus dla Ciebie już teraz!
            </h2>
            <p className="text-xs sm:text-sm text-white leading-relaxed font-normal">
              Chcesz przygotować się do rozmowy kwalifikacyjnej? Pobierz bezpłatny prezent:{" "}
              <strong className="font-bold">
                „20 pytań, które najprawdopodobniej spotkasz na rozmowie rekrutacyjnej”
              </strong>
            </p>
            <div className="pt-2">
              <button
                onClick={() => openBookingModal("gift")}
                className="bg-[#f5dc62] hover:bg-[#ebd04d] text-[#111111] font-bold text-xs uppercase px-6 py-3 tracking-wider transition-colors cursor-pointer inline-block"
              >
                KLIKNIJ TUTAJ
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Dlaczego warto mi zaufać? - Animated Counters */}
      <CountersSection />

      {/* 9. Bottom CTA Banner (section-4XzGrtRy52) - Exact Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://i.postimg.cc/g2xcddbW/68af624c8fd78442bc4b62d9.jpg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 10. Footer (section-LFkwfhkPm3) */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Left Column: Moje produkty */}
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          {/* Middle Spacer */}
          <div className="hidden md:block"></div>

          {/* Right Column: Teal box with legal copyright */}
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
