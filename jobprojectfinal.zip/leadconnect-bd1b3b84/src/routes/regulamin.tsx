import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/regulamin")({
  head: () => ({
    meta: [
      {
        title: "Regulamin | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Regulamin świadczenia usług (Terms of Service) oraz zgody marketingowe Job Project - Magdalena Chmielecka-Lisiecka.",
      },
      { property: "og:title", content: "Regulamin - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Regulamin świadczenia usług (Terms of Service) oraz zgody marketingowe Job Project.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegulaminPage,
});

export default function RegulaminPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative flex flex-col justify-between">
      {/* 1. Header with exact navigation matching the site style */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <a
              href="https://jobproject.com.pl/oferta"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Oferta
            </a>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <a
            href="https://jobproject.com.pl/oferta"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Oferta
          </a>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Main Regulamin Content Section */}
      <main className="flex-1 py-12 sm:py-16 bg-white">
        <div className="max-w-[1140px] mx-auto px-6 sm:px-12 text-[#222222]">
          {/* Main Title */}
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold text-[#111111] mb-6 tracking-tight">
            Regulamin
          </h1>

          <p className="font-bold text-base sm:text-[17px] text-[#222222] mb-6">
            Regulamin Świadczenia usług (Terms of Service)
          </p>

          {/* Points 1 - 7 */}
          <div className="space-y-4 text-xs sm:text-[13.5px] leading-relaxed text-[#555555]">
            <p>
              <strong className="font-bold text-[#111111]">1. Informacje ogólne</strong> Usługi
              świadczone są przez JobProject reprezentowaną przez{" "}
              <strong className="italic text-[#667085]">Magdalenę Chmielecką - Lisiecką</strong>.
              Usługi mają charakter osobistego wsparcia rozwojowego i nie stanowią działalności
              terapeutycznej ani medycznej.
            </p>

            <div>
              <p>
                <strong className="font-bold text-[#111111]">2. Rodzaj usług</strong> Oferowane
                usługi obejmują m.in.:
              </p>
              <ul className="list-disc pl-6 mt-1.5 space-y-1">
                <li>coaching kariery</li>
                <li>przygotowanie do rozmowy rekrutacyjnej</li>
                <li>konsultacja CV</li>
              </ul>
            </div>

            <p>
              <strong className="font-bold text-[#111111]">3. Rezerwacja i płatność</strong>{" "}
              Rezerwacja odbywa się poprzez formularz online, mailowo lub wiadomość prywatną. Po
              uzgodnieniu terminu klient dokonuje płatności przelewem na wskazany rachunek lub przez
              inną dostępną metodę. Rezerwacja jest wiążąca po zaksięgowaniu płatności.
            </p>

            <p>
              <strong className="font-bold text-[#111111]">4. Zmiana lub odwołanie sesji</strong>{" "}
              Odwołanie lub zmiana terminu możliwa jest najpóźniej 24 godziny przed sesją.
              Późniejsze odwołania mogą skutkować utratą wpłaty.
            </p>

            <p>
              <strong className="font-bold text-[#111111]">5. Charakter usług</strong> Usługi mają
              charakter rozwojowy, wspierający i intuicyjny. Nie są to porady psychologiczne ani
              medyczne i nie zastępują terapii. Osoba korzystająca z usług bierze pełną
              odpowiedzialność za decyzje podejmowane na podstawie sesji.
            </p>

            <p>
              <strong className="font-bold text-[#111111]">6. Prawa autorskie</strong> Wszelkie
              teksty (np. przemówienia) stworzone na zamówienie są chronione prawem autorskim.
              Klient otrzymuje prawo do ich wykorzystania na potrzeby prywatne lub zgodne z
              ustaleniami.
            </p>

            <p>
              <strong className="font-bold text-[#111111]">7. Kontakt</strong> Wszelkie pytania
              można kierować mailowo lub przez formularz kontaktowy.
            </p>
          </div>

          {/* Section: Zgody marketingowe */}
          <div className="mt-14 sm:mt-16 pt-6">
            <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-bold text-[#111111] mb-8 tracking-tight">
              Zgody marketingowe
            </h2>

            <div className="space-y-6">
              {/* Zgoda 1 */}
              <div>
                <h4 className="text-sm sm:text-base font-normal text-[#222222] mb-2">
                  1.{" "}
                  <strong className="font-bold">
                    Zgoda na przetwarzanie danych osobowych (RODO)
                  </strong>{" "}
                  :
                </h4>
                <blockquote className="bg-[#f9fafb] border-l-4 border-[#374151] py-3.5 px-5 text-xs sm:text-[13px] text-[#4b5563] leading-relaxed">
                  <p>
                    „Wyrażam zgodę na przetwarzanie moich danych osobowych w celu kontaktu i
                    realizacji usługi, zgodnie z{" "}
                    <Link to="/polityka-prywatnosci" className="text-[#65a30d] hover:underline">
                      Polityką Prywatności.
                    </Link>
                    ”
                  </p>
                </blockquote>
              </div>

              {/* Zgoda 2 */}
              <div>
                <h4 className="text-sm sm:text-base font-normal text-[#222222] mb-2">
                  2. <strong className="font-bold">Zgoda na kontakt marketingowy :</strong>
                </h4>
                <blockquote className="bg-[#f9fafb] border-l-4 border-[#374151] py-3.5 px-5 text-xs sm:text-[13px] text-[#4b5563] leading-relaxed">
                  <p>
                    „Wyrażam zgodę na otrzymywanie informacji handlowych i marketingowych drogą
                    elektroniczną od{" "}
                    <strong className="italic text-[#667085]">
                      Magdalena Chmielecka - Lisiecka
                    </strong>
                    .”
                  </p>
                </blockquote>
              </div>

              {/* Zgoda 3 */}
              <div>
                <h4 className="text-sm sm:text-base font-normal text-[#222222] mb-2">
                  3. <strong className="font-bold">Zgoda na automatyczne wiadomości :</strong>
                </h4>
                <blockquote className="bg-[#f9fafb] border-l-4 border-[#374151] py-3.5 px-5 text-xs sm:text-[13px] text-[#4b5563] leading-relaxed">
                  <p>
                    „Wyrażam zgodę na otrzymywanie wiadomości e-mail i SMS w celach związanych z
                    usługą oraz informacjami marketingowymi.”
                  </p>
                </blockquote>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* 3. Bottom CTA Banner (section-4XzGrtRy52) - Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 4. Footer (section-LFkwfhkPm3) */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Left Column: Moje produkty */}
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          {/* Middle Spacer */}
          <div className="hidden md:block"></div>

          {/* Right Column: Teal box with legal copyright */}
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
