import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/blog/kariera")({
  head: () => ({
    meta: [
      {
        title:
          "Nadaj karierze znaczenie czyli Purpose-Based Coaching | Job Project - Coaching Kariery",
      },
      {
        name: "description",
        content:
          "Purpose-Based Coaching to podejście, które traktuje sens (purpose, misję, znaczenie) jako kluczowy kompas dla decyzji zawodowych.",
      },
      {
        property: "og:title",
        content: "Nadaj karierze znaczenie czyli Purpose-Based Coaching",
      },
      {
        property: "og:description",
        content:
          "Purpose-Based Coaching to podejście, które traktuje sens (purpose, misję, znaczenie) jako kluczowy kompas dla decyzji zawodowych.",
      },
      {
        property: "og:image",
        content:
          "https://images.leadconnectorhq.com/image/f_webp/q_80/r_1200/u_https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png",
      },
      {
        name: "twitter:image",
        content:
          "https://images.leadconnectorhq.com/image/f_webp/q_80/r_1200/u_https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png",
      },
      { property: "og:type", content: "article" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: KarieraBlogPostPage,
});

export default function KarieraBlogPostPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header Navigation */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <a
              href="https://jobproject.com.pl/oferta"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Oferta
            </a>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="text-[#18c1c9] font-bold transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <a
            href="https://jobproject.com.pl/oferta"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Oferta
          </a>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Main Post Container (matching LeadConnectorHQ post template layout) */}
      <article className="max-w-[800px] mx-auto px-4 sm:px-6 py-10 sm:py-16 text-[#111111]">
        {/* Cover Image */}
        <div className="w-full mb-8 overflow-hidden rounded-xs">
          <img
            src="https://images.leadconnectorhq.com/image/f_webp/q_80/r_1200/u_https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png"
            alt="znaczenie kariery purpose based coaching JobProject Szczecin"
            className="w-full h-auto object-cover"
          />
        </div>

        {/* Post Title */}
        <h1 className="text-2xl sm:text-3xl lg:text-[38px] font-extrabold text-[#111111] leading-[1.25] tracking-tight mb-4">
          Nadaj karierze znaczenie czyli Purpose-Based Coaching
        </h1>

        {/* Category & Metadata */}
        <div className="flex flex-wrap items-center gap-2 text-xs sm:text-[13px] text-[#2b6cb0] font-medium mb-3">
          <Link to="/blog" className="hover:underline">
            budowanie kariery
          </Link>
        </div>
        <div className="flex items-center gap-2 text-xs sm:text-[13px] text-[#718096] mb-10 pb-6 border-b border-gray-100">
          <span>October 02, 2025</span>
          <span>•</span>
          <span>3 min read</span>
        </div>

        {/* Post Body Content */}
        <div className="space-y-8 text-sm sm:text-base leading-relaxed text-[#2d3748]">
          {/* Section 1 */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-[#1a202c]">
              Co to jest Purpose-Based Coaching?
            </h2>
            <p>
              Purpose-Based Coaching to podejście, które traktuje{" "}
              <strong className="font-bold">sens (purpose, misję, znaczenie)</strong> jako kluczowy
              kompas dla decyzji zawodowych. Chodzi o to, by nie tylko „mieć pracę”, ale by rola
              zawodowa była zgodna z tym, co dla Ciebie naprawdę istotne – wartościami, motywacjami,
              wewnętrznym powołaniem.
            </p>
            <p>W takiej relacji coachingowej pracuje się nad:</p>
            <ul className="list-disc list-inside space-y-2 pl-2 text-sm sm:text-base">
              <li>odkryciem własnego „dlaczego” (dlaczego robię to, co robię),</li>
              <li>zintegrowaniem tego „dlaczego” z wyborem ścieżki zawodowej,</li>
              <li>
                wyborem ról i działań, które dają poczucie sensu, nie tylko korzyści finansowej.
              </li>
            </ul>
            <p>To nie jest tylko filozofia – jest też badawczo uzasadnione podejście.</p>
          </section>

          <hr className="border-gray-200 my-8" />

          {/* Section 2 */}
          <section className="space-y-6">
            <h2 className="text-xl sm:text-2xl font-bold text-[#1a202c]">
              2. Co mówią badania naukowe
            </h2>

            <div className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#2d3748] italic">
                Badanie 1: Effect of purpose-based career coaching on career decision-making (2024)
              </h3>
              <p>
                W badaniu opublikowanym w czasopiśmie <i>Current Psychology</i> zastosowano
                eksperymentalny projekt i wywiady, by sprawdzić, jak coaching oparty na sensie
                wpływa na trudności w podejmowaniu decyzji zawodowych.{" "}
                <a
                  href="https://link.springer.com/article/10.1007/s12144-024-06247-3?utm_source=chatgpt.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="text-[#2b6cb0] font-medium hover:underline inline-flex items-center gap-1"
                >
                  SpringerLink ↗
                </a>
              </p>
              <p>
                Wyniki: uczestnicy, którzy przeszli przez ten coaching, znacząco zmniejszyli poziom
                trudności decyzyjnych względem grupy kontrolnej. Efekt był szczególnie silny w
                obszarach takich jak: niejasność w samowiedzy, brak klarowności co do opcji
                zawodowych, lęk przed popełnieniem błędu.
              </p>
              <p>
                To wskazuje, że <i>rozpoznanie sensu</i> pomaga przejść z paraliżu decyzyjnego do
                działania.
              </p>
            </div>

            <hr className="border-gray-100" />

            <div className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#2d3748] italic">
                Badanie 2: Purpose-Centered Career Development. A Strengths-Based Approach (Kosine i
                in.)
              </h3>
              <p>
                W pracy „Purpose-Centered Career Development” autorzy prezentują ramy integrujące
                sens i mocne strony.{" "}
                <a
                  href="https://www.researchgate.net/publication/269832879_Purpose-Centered_Career_Development_A_Strengths-Based_Approach_to_Finding_Meaning_and_Purpose_in_Careers?utm_source=chatgpt.com"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="text-[#2b6cb0] font-medium hover:underline inline-flex items-center gap-1"
                >
                  ResearchGate ↗
                </a>
              </p>
              <p>
                Założenia: warto wykorzystać mocne strony (talenty, predyspozycje) jako fundament
                dla działania w kierunku sensownej kariery. To nie oznacza ignorowania trudności,
                ale świadomego wyboru i dopasowania.
              </p>
            </div>

            <hr className="border-gray-100" />

            <div className="space-y-3">
              <h3 className="text-base sm:text-lg font-bold text-[#2d3748]">
                Uzupełnienie: stres, decyzyjność i limit poznawczy
              </h3>
              <p>
                W literaturze psychologicznej istnieje też dobrze udokumentowany związek między
                stresem a jakością decyzji:
              </p>
              <ul className="list-disc list-inside space-y-3 pl-2">
                <li>
                  Przegląd <i>Decision making under stress</i> pokazuje, że stres zmienia sposób, w
                  jaki wartościujemy opcje i uczy się wybierać szybkie, mniej optymalne strategie.{" "}
                  <a
                    href="https://pmc.ncbi.nlm.nih.gov/articles/PMC11061251/?utm_source=chatgpt.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-[#2b6cb0] font-medium hover:underline"
                  >
                    PMC+1
                  </a>
                </li>
                <li>
                  Stres zawęża naszą perspektywę, ogranicza kreatywność i skłania do wyborów
                  „bezpiecznych”.{" "}
                  <a
                    href="https://www.onrec.com/news/news-archive/the-subtle-ways-personal-stress-can-affect-decision-making-at-work?utm_source=chatgpt.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-[#2b6cb0] font-medium hover:underline"
                  >
                    onrec.com+1
                  </a>
                </li>
                <li>
                  W warunkach wysokiego obciążenia decyzyjnego łatwo podlega się efektowi „zmęczenia
                  decyzji” (decision fatigue), co obniża zdolność do podejmowania bardziej złożonych
                  wyborów.{" "}
                  <a
                    href="https://en.wikipedia.org/wiki/Decision_fatigue?utm_source=chatgpt.com"
                    target="_blank"
                    rel="noreferrer noopener"
                    className="text-[#2b6cb0] font-medium hover:underline"
                  >
                    Wikipedia
                  </a>
                </li>
              </ul>
              <p>
                Dlatego, gdy klient nie ma klarownego poczucia sensu, to decyzje zawodowe stają się
                podatne na brak wewnętrznej kotwicy – konstytuuje się chaos albo stagnacja.
              </p>
            </div>
          </section>

          <hr className="border-gray-200 my-8" />

          {/* Section 3 */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-[#1a202c]">
              3. Dlaczego warto skorzystać z podejścia w{" "}
              <a
                href="https://jobproject.com.pl/offer/career-program"
                target="_blank"
                rel="noreferrer noopener"
                className="text-[#2b6cb0] underline hover:text-[#18c1c9]"
              >
                ofercie
              </a>{" "}
              JobProject
            </h2>
            <ul className="list-disc list-inside space-y-4 pl-2">
              <li>
                Zyskujesz <strong className="font-bold">ramę myślenia</strong>, nie tylko „poradnik
                działań”.
              </li>
              <li>
                Pomagasz uniknąć sytuacji, że po 6 miesiącach stwierdzasz, że nowa praca „nie daje
                mi tego, czego potrzebuję”.
                <p className="mt-3">
                  Kiedy myślę o zmianie pracy, w pierwszej chwili czuję ekscytację. Ale zaraz potem
                  włącza się coś, co trudno opisać – lęk, napięcie, głos w głowie:{" "}
                  <i>„a co, jeśli się nie uda?”</i>. Okazuje się, że to wcale nie lenistwo ani brak
                  ambicji – to po prostu mój mózg.
                </p>
                <p className="mt-3">
                  Neurobiologia tłumaczy, że mózg nie lubi ryzyka i niepewności. Woli rzeczy znane,
                  nawet jeśli nie są idealne. To dlatego potrafię tkwić w pracy, która mnie nie
                  rozwija, tylko dlatego, że daje poczucie bezpieczeństwa.
                </p>
                <p className="mt-3">
                  Ale właśnie tu zaczyna się praca nad sobą. Jeśli wiem, jak reaguje mój mózg, mogę
                  mu pomóc:
                </p>
                <ul className="list-disc list-inside space-y-2 mt-2 pl-4">
                  <li>
                    budując <strong className="font-bold">małe nawyki</strong> (np. raz w tygodniu
                    sprawdzam oferty, zamiast od razu planować wielką zmianę),
                  </li>
                  <li>
                    <strong className="font-bold">ćwicząc rozmowy rekrutacyjne</strong> w
                    bezpiecznym środowisku, zanim stanę przed prawdziwym rekruterem,
                  </li>
                  <li>
                    ucząc się <strong className="font-bold">zarządzać stresem</strong> – od prostych
                    technik oddechowych po zmianę sposobu myślenia o błędach jako o lekcjach.
                  </li>
                </ul>
                <p className="mt-3">
                  To daje mi przewagę – nie walczę już sam ze sobą. Zaczynam rozumieć, że mój mózg
                  działa jak system alarmowy. A skoro wiem, jak on reaguje, mogę stopniowo oswajać
                  zmianę, zamiast paraliżować się strachem.
                </p>
              </li>
            </ul>
          </section>

          <hr className="border-gray-200 my-8" />

          {/* Section 4 */}
          <section className="space-y-4">
            <h2 className="text-xl sm:text-2xl font-bold text-[#1a202c]">
              4. Trudne pytania zwrotne (punkt zwrotny)
            </h2>
            <p>
              Poniżej zestaw 8–10 pytań, które można wykorzystać w sesji lub jako ćwiczenie
              refleksyjne. Mają pomóc klientowi dotrzeć do rdzenia:
            </p>
            <ol className="list-decimal list-inside space-y-3 pl-2">
              <li>
                Gdybyś miał opisać jedną wartość, bez której Twoja praca traci sens – co by to było?
              </li>
              <li>W jakich momentach Twojej kariery czułeś, że „to było to” — co wtedy robiłeś?</li>
              <li>
                Co by było „twoim wkładem” w świat, gdybyś nie musiał martwić się o pieniądze?
              </li>
              <li>
                Jakie role (zawodowe, społeczne) odmawiałeś w życiu, choć czułeś, że do nich
                pasujesz – i dlaczego?
              </li>
              <li>
                Gdy spojrzysz 5 lat w przód – co musi być prawdą, byś mógł powiedzieć: „Dokonałem
                dobrego wyboru”?
              </li>
              <li>
                Jakie kompromisy w dotychczasowych wyborach kariery sprawiały, że traciłeś
                wewnętrzną motywację?
              </li>
              <li>
                Co czujesz, gdy myślisz: „Nie pasuję do tego miejsca pracy” — jakie są emocje i na
                co chcą Ci coś powiedzieć?
              </li>
              <li>
                Co mogłoby stanowić dla Ciebie znak, że “zmiana kariery się powiodła” – poza
                statusem i pieniędzmi?
              </li>
            </ol>
          </section>
        </div>

        {/* Author Box */}
        <div className="mt-12 pt-8 border-t border-gray-100">
          <div className="bg-[#edf2f7]/50 rounded-lg p-4 flex items-center justify-between">
            <Link
              to="/o-mnie"
              className="flex items-center gap-3 hover:text-[#18c1c9] transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-[#3182ce] text-white flex items-center justify-center font-bold text-xs">
                👤
              </div>
              <span className="text-sm font-semibold text-[#2b6cb0]">
                Magdalena Chmielecka-Lisiecka
              </span>
            </Link>
          </div>
        </div>

        {/* Navigation Actions */}
        <div className="mt-8 flex flex-col items-center gap-4">
          <button
            onClick={scrollToTop}
            className="text-xs text-[#4a5568] hover:text-[#111111] transition-colors cursor-pointer"
          >
            Back to top
          </button>

          <Link
            to="/blog"
            className="text-xs text-[#2b6cb0] hover:underline flex items-center gap-1 cursor-pointer font-medium"
          >
            ← Back to Blog
          </Link>
        </div>
      </article>

      {/* 3. Bottom CTA Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 4. Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          <div className="hidden md:block"></div>

          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <a
                href="https://jobproject.com.pl/regulamin"
                target="_blank"
                rel="noreferrer noopener"
                className="font-bold italic text-black hover:underline"
              >
                Regulamin usług
              </a>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
