import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/podreczniki")({
  head: () => ({
    meta: [
      {
        title: "Podręczniki | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Podręczniki i materiały do samodzielnej pracy nad karierą od Job Project. Praktyczne przewodniki, które pomagają zaplanować rozwój zawodowy.",
      },
      { property: "og:title", content: "Podręczniki - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content: "Podręczniki i materiały do samodzielnej pracy nad karierą od Job Project.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PodrecznikiLayout,
});

export default function PodrecznikiLayout() {
  return <Outlet />;
}
