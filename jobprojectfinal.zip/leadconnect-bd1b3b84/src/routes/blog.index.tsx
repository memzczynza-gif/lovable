import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/blog/")({
  head: () => ({
    meta: [
      {
        title: "Blog | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Czytaj najnowsze artykuły z zakresu coachingu kariery, rozwoju zawodowego i planowania ścieżki zawodowej od Job Project.",
      },
      { property: "og:title", content: "Blog - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Czytaj najnowsze artykuły z zakresu coachingu kariery, rozwoju zawodowego i planowania ścieżki zawodowej.",
      },
      {
        property: "og:image",
        content:
          "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png",
      },
      {
        name: "twitter:image",
        content:
          "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BlogPage,
});

export default function BlogPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header with exact navigation matching original layout */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="text-[#18c1c9] font-bold transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <a
            href="https://jobproject.com.pl/oferta"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Oferta
          </a>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Page Header Banner - "BLOG" */}
      <section className="relative w-full bg-[#1A3326] py-16 sm:py-[72px] text-center text-white overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-overlay"
          style={{
            backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold tracking-tight text-white leading-tight">
            BLOG
          </h1>
        </div>
      </section>

      {/* 3. Main Blog Content Section */}
      <section className="py-14 sm:py-20 bg-white min-h-[500px]">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
            {/* Left Column: Share This */}
            <div className="lg:col-span-3 flex flex-col items-center lg:items-start space-y-3">
              <span className="text-xs font-semibold text-[#666666] tracking-wide">Share This</span>
              <div className="flex items-center gap-2">
                <a
                  href="mailto:?subject=Purpose-Based%20Coaching&body=https://jobproject.com.pl/blog/kariera"
                  className="w-9 h-9 bg-[#6c757d] hover:bg-[#5a6268] text-white flex items-center justify-center transition-colors rounded-xs"
                  aria-label="Share via Mail"
                >
                  <img
                    src="https://stcdn.leadconnectorhq.com/funnel/icons/white/mail-white.svg"
                    alt="Mail"
                    className="w-4 h-4 object-contain"
                  />
                </a>
                <a
                  href="https://www.facebook.com/sharer/sharer.php?u=https://jobproject.com.pl/blog/kariera"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="w-9 h-9 bg-[#3b5998] hover:bg-[#2d4373] text-white flex items-center justify-center transition-colors rounded-xs"
                  aria-label="Share on Facebook"
                >
                  <img
                    src="https://stcdn.leadconnectorhq.com/funnel/icons/white/facebook-white.svg"
                    alt="Facebook"
                    className="w-4 h-4 object-contain"
                  />
                </a>
                <a
                  href="https://www.linkedin.com/sharing/share-offsite/?url=https://jobproject.com.pl/blog/kariera"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="w-9 h-9 bg-[#0077b5] hover:bg-[#005582] text-white flex items-center justify-center transition-colors rounded-xs"
                  aria-label="Share on LinkedIn"
                >
                  <img
                    src="https://stcdn.leadconnectorhq.com/funnel/icons/white/linkedin-white.svg"
                    alt="LinkedIn"
                    className="w-4 h-4 object-contain"
                  />
                </a>
                <a
                  href="https://twitter.com/intent/tweet?url=https://jobproject.com.pl/blog/kariera"
                  target="_blank"
                  rel="noreferrer noopener"
                  className="w-9 h-9 bg-[#333333] hover:bg-[#111111] text-white flex items-center justify-center transition-colors rounded-xs"
                  aria-label="Share on X"
                >
                  <img
                    src="https://stcdn.leadconnectorhq.com/funnel/icons/white/x-white.svg"
                    alt="X"
                    className="w-4 h-4 object-contain"
                  />
                </a>
              </div>
            </div>

            {/* Center/Right Area: Blog Post Card */}
            <div className="lg:col-span-9 flex justify-center lg:justify-start">
              <div className="w-full max-w-[420px] bg-white border border-[#e5e7eb] rounded-xs overflow-hidden shadow-xs hover:shadow-md transition-shadow">
                {/* Blog Card Image */}
                <Link to="/blog/kariera" className="block overflow-hidden">
                  <img
                    src="https://images.leadconnectorhq.com/image/f_webp/q_80/r_1200/u_https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/68dec8f4bd01df750a639aed.png"
                    alt="Nadaj karierze znaczenie czyli Purpose-Based Coaching"
                    className="w-full h-auto object-cover hover:scale-102 transition-transform duration-300"
                  />
                </Link>

                {/* Blog Card Content */}
                <div className="p-6 space-y-3">
                  <h2 className="text-base sm:text-lg font-bold text-[#111111] leading-snug">
                    <Link
                      to="/blog/kariera"
                      className="hover:text-[#18c1c9] transition-colors text-left cursor-pointer"
                    >
                      Nadaj karierze znaczenie czyli Purpose-Based Coaching
                    </Link>
                  </h2>

                  <p className="text-xs sm:text-[13px] text-[#4b5563] leading-relaxed">
                    Purpose-Based Coaching to podejście, które traktuje sens (purpose, misję,
                    znaczenie) jako kluczowy kompas dla decyzji zawodowych. Chodzi o to, by nie
                    tylko „mieć pracę”, ale by rola zawodowa była zgod...{" "}
                    <Link
                      to="/blog/kariera"
                      className="text-[#18c1c9] font-medium hover:underline cursor-pointer"
                    >
                      ...more
                    </Link>
                  </p>

                  <div className="pt-2 border-t border-gray-100 space-y-1">
                    <div className="text-xs text-[#6b7280]">budowanie kariery</div>
                    <div className="text-[11px] text-[#9ca3af]">October 02, 2025 • 3 min read</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Bottom CTA Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 5. Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          <div className="hidden md:block"></div>

          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <a
                href="https://jobproject.com.pl/regulamin"
                target="_blank"
                rel="noreferrer noopener"
                className="font-bold italic text-black hover:underline"
              >
                Regulamin usług
              </a>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
