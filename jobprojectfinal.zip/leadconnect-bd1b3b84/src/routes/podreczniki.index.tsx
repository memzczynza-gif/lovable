import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/podreczniki/")({
  head: () => ({
    meta: [
      {
        title: "Podręczniki | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Podręczniki i materiały do samodzielnej pracy nad karierą od Job Project. Praktyczne przewodniki, które pomagają zaplanować rozwój zawodowy.",
      },
      { property: "og:title", content: "Podręczniki - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content: "Podręczniki i materiały do samodzielnej pracy nad karierą od Job Project.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PodrecznikiIndexPage,
});

export default function PodrecznikiIndexPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  // Podręczniki — dodany interaktywny e-book Poznaj Siebie Zawodowo oraz Gdzie Jestem i Co Mnie Blokuje
  const books = [
    {
      title: "Poznaj Siebie Zawodowo",
      subtitle:
        "Interaktywny e-book i ćwiczenia: mapa energii, wartości, kotwice kariery oraz środowisko pracy.",
      gradient: "from-[#0f7a7f] to-[#123033]",
      coverUrl:
        "https://storage.googleapis.com/msgsndr/qBkeaVOgtwtvWfdxJfrG/media/697c7bd2f7a8772b94674e3c.png",
      link: "/podreczniki/poznaj-siebie-zawodowo",
      available: true,
    },
    {
      title: "Gdzie jestem i co mnie blokuje",
      subtitle:
        "Interaktywny e-book i ćwiczenia: oś czasu kariery, mapa energii zadań, SWOT, praca z krytykiem i kalkulator utknięcia.",
      gradient: "from-[#1F4E38] to-[#0f2c20]",
      coverUrl:
        "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/69ce55cdf6d8a253cb7e510d.png",
      link: "/podreczniki/gdzie-jestem-i-co-mnie-blokuje",
      available: true,
    },
  ];

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>

          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile Horizontal Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <Link to="/oferta" className="whitespace-nowrap hover:text-[#18c1c9]">
            Oferta
          </Link>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* Hero Header Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-16 text-center min-h-[200px] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative z-10 px-6 max-w-4xl mx-auto"
        >
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight drop-shadow-md">
            Podręczniki
          </h1>
        </motion.div>
      </section>

      {/* Intro */}
      <section className="py-12 sm:py-16 bg-white text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-[800px] mx-auto px-6 space-y-4"
        >
          <h2 className="text-2xl sm:text-3xl font-bold text-[#111111]">
            Materiały do samodzielnej pracy nad karierą
          </h2>
          <p className="text-sm sm:text-base text-[#444444] leading-relaxed font-normal">
            Praktyczne przewodniki, które pomogą Ci krok po kroku zaplanować rozwój zawodowy,
            przygotować dokumenty aplikacyjne i świadomie kształtować ścieżkę kariery.
          </p>
        </motion.div>
      </section>

      {/* Book Cards */}
      <section className="pb-16 sm:pb-24 bg-white">
        <div className="max-w-[1140px] mx-auto px-6 sm:px-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-14">
            {books.map((book, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.12 }}
                whileHover={{ y: -6 }}
                className="flex flex-col items-center text-center group"
              >
                {/* Book cover / image */}
                {book.coverUrl ? (
                  <Link to={book.link || "#"} className="w-full max-w-[300px] block">
                    <img
                      src={book.coverUrl}
                      alt={book.title}
                      className="w-full max-w-[300px] aspect-[3/4] object-cover rounded-lg shadow-lg group-hover:shadow-2xl transition-all duration-300 transform group-hover:-translate-y-1"
                    />
                  </Link>
                ) : (
                  <div
                    className={`relative w-full max-w-[300px] aspect-[3/4] rounded-lg bg-gradient-to-br ${book.gradient} shadow-lg group-hover:shadow-xl transition-shadow flex items-center justify-center p-6 overflow-hidden`}
                  >
                    {/* Spine highlight */}
                    <div className="absolute left-0 top-0 bottom-0 w-2 bg-black/15" />
                    {/* Sheen */}
                    <div className="absolute inset-0 bg-gradient-to-br from-white/10 via-transparent to-black/20" />
                    <div className="relative z-10 flex flex-col items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center backdrop-blur-sm">
                        <svg
                          className="w-6 h-6 text-white"
                          viewBox="0 0 24 24"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        >
                          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
                        </svg>
                      </div>
                      <span className="text-white/80 text-[11px] uppercase tracking-widest font-semibold">
                        Podręcznik
                      </span>
                    </div>
                  </div>
                )}

                {/* Book title + description */}
                <div className="mt-6 max-w-[320px] space-y-2">
                  <h3 className="text-lg sm:text-xl font-bold text-[#111111] leading-snug">
                    {book.title}
                  </h3>
                  <p className="text-sm text-[#666666] leading-relaxed font-normal">
                    {book.subtitle}
                  </p>
                  <div className="pt-3">
                    {book.available && book.link ? (
                      <Link
                        to={book.link}
                        className="inline-block bg-[#18c1c9] hover:bg-[#15adb4] text-white font-semibold text-sm px-6 py-2.5 rounded-full transition-all shadow-sm hover:shadow"
                      >
                        Otwórz e-book
                      </Link>
                    ) : (
                      <span className="inline-block bg-[#e9e9e9] text-[#999999] font-semibold text-sm px-6 py-2.5 rounded-full cursor-not-allowed">
                        Wkrótce dostępny
                      </span>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom CTA Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          <div className="hidden md:block"></div>

          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
