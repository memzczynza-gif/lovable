import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/o-mnie")({
  head: () => ({
    meta: [
      {
        title: "O Mnie | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Z wykształcenia jestem magistrem Zarządzania oraz coachem kariery, z doświadczeniem w firmach międzynarodowych. Poznaj mnie bliżej.",
      },
      { property: "og:title", content: "O Mnie - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Z wykształcenia jestem magistrem Zarządzania oraz coachem kariery. Chętnie pomogę Ci zrealizować Twój Projekt Praca.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: OMniePage,
});

export default function OMniePage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header with exact navigation matching home page */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Brand Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link
              to="/o-mnie"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap text-[#18c1c9] font-bold">
            O Mnie
          </Link>
          <Link to="/oferta" className="whitespace-nowrap hover:text-[#18c1c9]">
            Oferta
          </Link>
          <Link to="/zespol" className="whitespace-nowrap hover:text-[#18c1c9]">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Page Header Banner (section-A4Ecbeo94) - Background overlay with exact title "Kilka słów o mnie..." */}
      <section className="relative w-full bg-[#1A3326] py-16 sm:py-[72px] text-center text-white overflow-hidden">
        {/* Mountain background image overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-overlay"
          style={{
            backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold tracking-tight text-white leading-tight">
            Kilka słów o mnie...
          </h1>
        </div>
      </section>

      {/* 3. Main Content Section (section-27vs9KnN-i) */}
      <section className="py-12 sm:py-16 bg-white">
        <div className="max-w-[1140px] mx-auto px-6 sm:px-12 text-[#222222]">
          <div className="max-w-[1080px] mx-auto space-y-7 text-[15px] sm:text-[16px] leading-[1.8] text-[#222222] font-normal">
            <p className="text-center sm:text-left">
              Z wykształcenia jestem magistrem Zarządzania oraz coachem kariery, z doświadczeniem w
              firmach międzynarodowych w branżach: telekomunikacja, farmacja, centra usług
              wspólnych. Rozumiem wyzwania świata korporacyjnego i jego pęd. Mieszkałam, studiowałam
              i pracowałam w Irlandii, Szwecji i Polsce. Od zawsze interesował mnie człowiek, jego
              potrzeby, motywacje i cele. W życiu zawodowym dokonywałam zmian szukając “swojego
              miejsca”.
            </p>

            <p className="font-bold italic text-[#222222] text-center max-w-[900px] mx-auto py-2 leading-relaxed">
              Podążałam za pracą, która połączyłaby moje umiejętności, zainteresowania, wartości i
              cechy osobowościowe w spójną całość, była źródłem satysfakcji i pozwoliłaby mi się w
              pełni realizować.
            </p>

            <p className="text-center sm:text-left">
              Moje poszukiwania trwały ponad 7 lat. W miejscu, w którym jestem dzisiaj odczuwam
              harmonię, radość, spokój i… po prostu bardzo lubię ten stan. Chętnie pomogę Ci
              zrealizować Twój Projekt Praca i przejść przez proces lub poszczególne jego etapy
              szybciej i skuteczniej.
            </p>

            <p className="font-bold italic text-[#222222] text-center max-w-[900px] mx-auto py-2 leading-relaxed">
              Doceniam znaczenie równowagi i uważam, że praca jest jej istotnym elementem.
            </p>

            <p className="text-center sm:text-left">
              Przechodząc dwa razy przez proces zwolnień grupowych, w moje życie wdarł się chaos.
              Wykorzystałam ten czas na podsumowanie dotychczasowej drogi zawodowej oraz bilans
              moich zasobów i potencjału. Dzięki pracy nad rozwojem własnym, budowaniu nowych
              kompetencji, poznawaniu siebie i autorefleksji, pogłębianiu wrażliwości i odporności,
              zrozumiałam, że nawet trudne sytuacje zawodowe mogą być “katalizatorem zmian” i
              przynieść pomyślne rezultaty. Z moich doświadczeń zawodowych i osobistych oraz
              wieloletniej pracy z ludźmi w obszarze coachingu kariery powstał JOB PROJECT.
            </p>

            {/* Photo Image (image-7x3J30xvtN) - matching original exact width and centering */}
            <div className="pt-10 pb-8 flex justify-center">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68acb0daa7e5980ec684e15a.jpeg"
                alt="Magdalena Chmielecka-Lisiecka"
                className="w-full max-w-[960px] h-auto object-cover rounded-none"
              />
            </div>

            {/* Subheading & CTA Button */}
            <div className="text-center pt-2 space-y-7">
              <h2 className="text-xl sm:text-2xl lg:text-[28px] font-bold text-[#222222] leading-tight max-w-[850px] mx-auto">
                Nie odkładaj zmian na później. Zrób pierwszy krok, sięgnij po nową pracę!
              </h2>
              <div className="pt-1">
                <button
                  onClick={() => openBookingModal("consultation")}
                  className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.99] text-white font-medium text-sm sm:text-[15px] px-8 py-3.5 rounded-full transition-all cursor-pointer inline-block shadow-none"
                >
                  Zapraszam na bezpłatną konsultację
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Bottom CTA Banner (section-4XzGrtRy52) - Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 5. Footer (section-LFkwfhkPm3) */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Left Column: Moje produkty */}
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          {/* Middle Spacer */}
          <div className="hidden md:block"></div>

          {/* Right Column: Teal box with legal copyright */}
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
