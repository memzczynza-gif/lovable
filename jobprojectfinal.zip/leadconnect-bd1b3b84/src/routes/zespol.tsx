import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/zespol")({
  head: () => ({
    meta: [
      {
        title: "Zespół | Job Project - Coaching Kariery | Magdalena Chmielecka-Lisiecka",
      },
      {
        name: "description",
        content:
          "Poznaj zespół Job Project. Aneta Kosidło - praktyk, trener oraz osoba wspierająca w rozwoju zawodowym i osobistym z ponad 15-letnim doświadczeniem.",
      },
      { property: "og:title", content: "Zespół - Job Project Coaching Kariery" },
      {
        property: "og:description",
        content:
          "Poznaj zespół Job Project. Aneta Kosidło - praktyk, trener oraz osoba wspierająca w rozwoju zawodowym i osobistym.",
      },
      {
        property: "og:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6a070414937389dca046d262.jpeg",
      },
      {
        name: "twitter:image",
        content:
          "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6a070414937389dca046d262.jpeg",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ZespolPage,
});

export default function ZespolPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* 1. Header with exact navigation matching original layout */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project Logo"
                className="w-[125px] sm:w-[130px] h-auto object-contain"
              />
            </Link>
          </div>

          {/* Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link to="/oferta" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Oferta
            </Link>
            <Link
              to="/zespol"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>

          {/* Right Action: Button + Social Icons */}
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] active:scale-[0.98] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer shadow-xs tracking-normal whitespace-nowrap"
            >
              Darmowa konsultacja
            </button>

            {/* Social Icons (Facebook & LinkedIn) */}
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="Facebook"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
                aria-label="LinkedIn"
                className="hover:opacity-85 transition-opacity"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-xs"
                />
              </a>
            </div>
          </div>
        </div>

        {/* Mobile / Tablet Horizontal Scroll Menu */}
        <div className="xl:hidden flex items-center gap-4 overflow-x-auto py-2 px-1 text-xs sm:text-sm font-medium text-[#222222] border-t border-[#ebd7b0]/20 mt-2 scrollbar-none">
          <Link to="/" className="whitespace-nowrap hover:text-[#18c1c9]">
            Home
          </Link>
          <Link to="/o-mnie" className="whitespace-nowrap hover:text-[#18c1c9]">
            O Mnie
          </Link>
          <a
            href="https://jobproject.com.pl/oferta"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Oferta
          </a>
          <Link to="/zespol" className="whitespace-nowrap text-[#18c1c9] font-bold">
            Zespół
          </Link>
          <Link to="/referencje" className="whitespace-nowrap hover:text-[#18c1c9]">
            Referencje
          </Link>
          <Link to="/blog" className="whitespace-nowrap hover:text-[#18c1c9]">
            Blog
          </Link>
          <Link to="/podreczniki" className="whitespace-nowrap hover:text-[#18c1c9]">
            Podręczniki
          </Link>

          <Link to="/quizy" className="whitespace-nowrap hover:text-[#18c1c9]">
            Quizy
          </Link>
          <a
            href="https://jobproject.com.pl/grupa-mastermind"
            className="whitespace-nowrap hover:text-[#18c1c9]"
          >
            Grupa Mastermind
          </a>
          <Link to="/kontakt" className="whitespace-nowrap hover:text-[#18c1c9]">
            Kontakt
          </Link>
        </div>
      </header>

      {/* 2. Page Header Banner (section-Mu6s7Un7V) - "Zespół" */}
      <section className="relative w-full bg-[#1A3326] py-16 sm:py-[72px] text-center text-white overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-40 mix-blend-overlay"
          style={{
            backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
          }}
        />
        <div className="relative z-10 max-w-4xl mx-auto px-6">
          <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-extrabold tracking-tight text-white leading-tight">
            Zespół
          </h1>
        </div>
      </section>

      {/* 3. Team Member Section: Aneta Kosidło (section-n1R17u3_Pd) */}
      <section className="py-14 sm:py-20 bg-white">
        <div className="max-w-[1240px] mx-auto px-6 sm:px-12 lg:px-16">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-start">
            {/* Left Column: Photo */}
            <div className="lg:col-span-6 xl:col-span-5 flex justify-center lg:justify-start">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6a070414937389dca046d262.jpeg"
                alt="Aneta Kosidło"
                className="w-full max-w-[500px] h-auto object-cover rounded-none shadow-none"
              />
            </div>

            {/* Right Column: Text Bio */}
            <div className="lg:col-span-6 xl:col-span-7 space-y-5 text-[#222222]">
              <h2 className="text-2xl sm:text-3xl lg:text-[34px] font-extrabold text-[#111111] leading-tight">
                Aneta Kosidło
              </h2>

              <p className="text-xs sm:text-[13px] lg:text-[13.5px] text-[#444444] leading-[1.7] font-normal">
                Nazywam się Aneta Kosidło i od lat działam jako praktyk, trener oraz osoba
                wspierająca innych w rozwoju zawodowym i osobistym. Mam ponad 15 lat doświadczenia w
                środowisku biznesowym i korporacyjnym - od sprzedaży i obsługi klienta, po role
                managerskie, zarządzanie projektami, organizację wydarzeń oraz współpracę z
                klientami indywidualnymi i biznesowymi.
              </p>

              <p className="text-xs sm:text-[13px] lg:text-[13.5px] text-[#444444] leading-[1.7] font-normal">
                Przez lata łączyłam świat korporacji z projektami rozwojowymi, szkoleniowymi i
                warsztatowymi. Dziś działam jako freelancer, współpracując z inspirującymi ludźmi i
                projektami związanymi z rozwojem, zmianą zawodową i aktywizacją uczestników. Na co
                dzień prowadzę warsztaty, rozmowy rozwojowe oraz działania wspierające odkrywanie
                potencjału, budowanie pewności siebie i rozwój kompetencji.
              </p>

              <p className="text-xs sm:text-[13px] lg:text-[13.5px] text-[#444444] leading-[1.7] font-normal">
                W swojej pracy stawiam przede wszystkim na człowieka, relacje i praktyczne
                podejście. Łączę doświadczenie biznesowe, sprzedażowe i projektowe z umiejętnością
                pracy z ludźmi oraz budowania długofalowych relacji opartych na zaufaniu i
                skutecznej komunikacji.
              </p>

              <p className="text-xs sm:text-[13px] lg:text-[13.5px] text-[#444444] leading-[1.7] font-normal">
                Prywatnie jestem pasjonatką podróży i poznawania ludzi oraz kultur, co nauczyło mnie
                otwartości, elastyczności i spojrzenia na rozwój człowieka z szerszej perspektywy.
              </p>

              <div className="pt-1">
                <p className="text-xs sm:text-[13px] lg:text-[13.5px] text-[#444444] font-normal mb-2">
                  Moim mottem jest:
                </p>
                <blockquote className="bg-[#f8f9fa] border-l-2 border-[#111111]/30 p-3 sm:p-4 text-xs sm:text-[13px] italic text-[#333333]">
                  „Jeśli naprawdę czegoś chcesz - zawsze znajdziesz sposób.”
                </blockquote>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Bottom CTA Banner (section-4XzGrtRy52) - Background: 68af624c8fd78442bc4b62d9.jpeg */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h3 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h3>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer inline-block tracking-normal"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* 5. Footer (section-LFkwfhkPm3) */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700 border-t border-gray-100">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Left Column: Moje produkty */}
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>

          {/* Middle Spacer */}
          <div className="hidden md:block"></div>

          {/* Right Column: Teal box with legal copyright */}
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1 rounded-none shadow-none">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <a
                href="https://jobproject.com.pl/regulamin"
                target="_blank"
                rel="noreferrer noopener"
                className="font-bold italic text-black hover:underline"
              >
                Regulamin usług
              </a>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Interactive Chat Widget & Modal */}
      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
