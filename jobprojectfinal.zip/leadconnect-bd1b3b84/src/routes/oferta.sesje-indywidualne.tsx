import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { motion } from "framer-motion";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/oferta/sesje-indywidualne")({
  head: () => ({
    meta: [
      { title: "Sesje Indywidualne - Job Project Coaching Kariery" },
      {
        name: "description",
        content: "Proces coachingu kariery i sesje indywidualne. Pakiet PRO oraz Pakiet START.",
      },
    ],
  }),
  component: SesjeIndywidualnePage,
});

export default function SesjeIndywidualnePage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  const areas = [
    {
      title: "Rozpoznanie Sytuacji Wyjściowej",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e40123b9338862c8b43.png",
    },
    {
      title: "Wizja Zawodowa",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a00de61bde797b8f7.jpeg",
    },
    {
      title: "Cele i Motywacja",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a00de61a56697b8fa.jpeg",
    },
    {
      title: "Analiza Twoich Zasobów",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a00de617dc997b8f8.jpeg",
    },
    {
      title: "Określenie Możliwości Zawodowych",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a2aa5a5ea4052d67f.jpeg",
    },
    {
      title: "Osobisty Plan Działania I Edukacji",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a5c255c8140246bdc.jpeg",
    },
    {
      title: "CV",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a2c366710e5b12901.jpeg",
    },
    {
      title: "Wybór Najlepszej Strategii Szukania Pracy",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8ad79817388f3190a7.jpeg",
    },
    {
      title: "Przygotowanie Do Rozmowy Rekrutacyjnej",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8acf02b63345c32088.jpeg",
    },
    {
      title: "Symulacja Rozmowy Rekrutacyjnej",
      img: "https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af6e8a00de61c32e97b8f9.jpeg",
    },
  ];

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link
              to="/oferta"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer"
            >
              Darmowa konsultacja
            </button>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center min-h-[220px] flex items-center justify-center"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <h1 className="relative z-10 text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight">
          Sesje indywidualne
        </h1>
      </section>

      {/* Description Section */}
      <section className="py-14 bg-white text-center">
        <div className="max-w-[900px] mx-auto px-6 space-y-6 text-[#444444] text-base sm:text-[17px] leading-relaxed">
          <p>
            Jeśli czujesz, że aktualna praca nie daje już satysfakcji, chcesz zmienić obszar
            zawodowy by rozwinąć swoją karierę, chcesz zmian a nie masz jeszcze wizji wymarzonej
            pracy, lub wiesz czego chcesz ale “coś” Cię powstrzymuje przed działaniem – pomogę Ci
            ruszyć z miejsca i zwiększyć Twoją skuteczność.
          </p>
          <p>
            Proces coachingu kariery jest wieloetapowy. W zależności od potrzeb i osobistej sytuacji
            zawodowej, klienci wybierają przejście przez wybrane elementy lub kompletną całość.
          </p>
        </div>
      </section>

      {/* Areas Grid */}
      <section className="py-10 bg-gray-50/50">
        <div className="max-w-[1140px] mx-auto px-6 text-center">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#111111] mb-10">
            Tak wyglądają jego poszczególne obszary:
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
            {areas.map((area, idx) => (
              <div key={idx} className="flex flex-col items-center group">
                <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden border-2 border-[#18c1c9]/30 p-1 bg-white shadow-xs group-hover:border-[#18c1c9] transition-all">
                  <img
                    src={area.img}
                    alt={area.title}
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <p className="mt-3 text-xs sm:text-sm font-semibold text-[#222222] max-w-[140px] leading-snug">
                  {area.title}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Packages */}
      <section className="py-16 bg-white">
        <div className="max-w-[1100px] mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center text-[#111111] mb-12">
            Wybierz plan dopasowany do swoich potrzeb
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Pakiet PRO */}
            <div className="border border-[#18c1c9] rounded-2xl overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
              <div>
                <div className="bg-[#18c1c9] text-white text-center py-4 px-6 text-xl font-bold">
                  Pakiet PRO
                </div>
                <div className="p-6 sm:p-8 space-y-6 text-[#333333] text-sm sm:text-base leading-relaxed">
                  <p>
                    Pakiet skierowany jest do osób, które chcą szybko osiągnąć swój cel zawodowy.
                    Jest to bardzo intensywna forma współpracy i daje Ci możliwość zrealizowania
                    Twoich celów zawodowych w możliwie najkrótszym czasie.
                  </p>
                  <div className="space-y-4 pt-2">
                    <div className="flex items-start gap-3">
                      <img
                        src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                        alt="Check"
                        className="w-5 h-5 shrink-0 mt-1"
                      />
                      <p className="font-medium">
                        3 x 90 min sesje miesięcznie, regularne cotygodniowe spotkania, które
                        pozwolą Ci szybciej zrealizować Twój cel
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <img
                        src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                        alt="Check"
                        className="w-5 h-5 shrink-0 mt-1"
                      />
                      <p className="font-medium">
                        1 konsultację on-line Twojego CV podczas której zaproponuję Ci co warto
                        poprawić aby zostać zauważonym przez pracodawcę i rekrutera wśród
                        istniejącej konkurencji
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 pt-0 text-center">
                <button
                  onClick={() => openBookingModal("consultation")}
                  className="w-full bg-[#f5dc62] hover:bg-[#ebd04d] text-black font-bold uppercase tracking-wider text-sm py-3.5 rounded-full transition-colors cursor-pointer"
                >
                  Umów się na sesję
                </button>
              </div>
            </div>

            {/* Pakiet START */}
            <div className="border border-[#18c1c9] rounded-2xl overflow-hidden flex flex-col justify-between shadow-xs hover:shadow-md transition-shadow">
              <div>
                <div className="bg-[#18c1c9] text-white text-center py-4 px-6 text-xl font-bold">
                  Pakiet START
                </div>
                <div className="p-6 sm:p-8 space-y-6 text-[#333333] text-sm sm:text-base leading-relaxed">
                  <p>
                    Pakiet skierowany jest do osób, które chcą osiągnąć swój cel zawodowy i
                    wybierają spokojniejsze tempo pracy. Jest to efektywna forma współpracy, dająca
                    dużą elastyczność.
                  </p>
                  <div className="space-y-4 pt-2">
                    <div className="flex items-start gap-3">
                      <img
                        src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                        alt="Check"
                        className="w-5 h-5 shrink-0 mt-1"
                      />
                      <p className="font-medium">
                        2 x 90 min sesje miesięcznie, w wybranym przez siebie terminie.
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <img
                        src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                        alt="Check"
                        className="w-5 h-5 shrink-0 mt-1"
                      />
                      <p className="font-medium">
                        1 konsultację on-line Twojego CV podczas której zaproponuję Ci co warto
                        poprawić aby zostać zauważonym przez pracodawcę i rekrutera wśród
                        istniejącej konkurencji
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              <div className="p-6 pt-0 text-center">
                <button
                  onClick={() => openBookingModal("consultation")}
                  className="w-full bg-[#f5dc62] hover:bg-[#ebd04d] text-black font-bold uppercase tracking-wider text-sm py-3.5 rounded-full transition-colors cursor-pointer"
                >
                  Umów się na sesję
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bottom Banners */}
      <section className="py-12 bg-white text-center border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-6 space-y-5">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#111111]">
            Gotowa/y, żeby Twój profil zaczął pracować na Ciebie?
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na bezpłatną konsultację!
            </button>
          </div>
        </div>
      </section>

      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>
          <div className="hidden md:block"></div>
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
