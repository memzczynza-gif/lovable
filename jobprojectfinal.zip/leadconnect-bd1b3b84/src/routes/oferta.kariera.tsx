import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { LeadModal } from "@/components/LeadModal";
import { ChatWidget } from "@/components/ChatWidget";

export const Route = createFileRoute("/oferta/kariera")({
  head: () => ({
    meta: [
      { title: "Kariera idealnie dobrana do Ciebie - Job Project" },
      {
        name: "description",
        content: "Program coachingowo - szkoleniowy: Kariera idealnie dobrana do Ciebie.",
      },
    ],
  }),
  component: KarieraPage,
});

export default function KarieraPage() {
  const [modalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<"consultation" | "gift" | "offer" | "more">(
    "consultation",
  );

  const navigate = useNavigate();

  const openBookingModal = (type: "consultation" | "gift" | "offer" | "more" = "consultation") => {
    navigate({ to: "/kontakt" });
  };

  const forWhom = [
    "dla tych, którzy chcą czerpać zadowolenie i satysfakcję z pracy",
    "dla tych, którzy chcą określić swój potencjał zawodowy i wykorzystywać go na codzień",
    "dla tych, którzy chcą rozpoznać swoją wartość, atuty i mocne strony oraz wiedzieć co ich wyróżnia",
    "dla tych, którzy chcą zyskać jasność jakie zawody pasują do nich w sposób naturalny",
    "dla tych, którzy mając pewne doświadczenie zawodowe, potrzebują sprawdzić czy rozważane ścieżki edukacji i kariery są dobrym wyborem",
    "dla tych, co chcą zmienić pracę, ale nie mają jasności w jaki nowy obszar mogliby przetransferować swoje zasoby",
    "dla tych, którzy chcą stworzyć przemyślany PLAN ROZWOJU WŁASNEJ KARIERY i potrzebują w tym wsparcia",
  ];

  const includes = [
    "10 godzin indywidualnego szkolenia i coachingu",
    "kompleksowy indywidualny raport Twojego potencjału i atutów (j.angielski) ze szczegółowym omówieniem ze mną każdej jego sekcji",
    "listę zawodów oraz obszarów zawodowych dopasowanych do Ciebie (->jedyna taka opcja na rynku<-)",
    "materiały i ćwiczenia do wykonania, dzięki którym będziesz realizować zmianę",
    "50% zniżki za dostęp do wygrywającego nagrody narzędzia psychometrycznego www.careerdecisions.ie",
  ];

  return (
    <div className="min-h-screen bg-white text-[#222222] font-['Manrope',sans-serif] selection:bg-[#18c1c9] selection:text-white relative">
      {/* Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 lg:px-12 xl:px-16 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center shrink-0">
            <Link to="/" className="inline-block transition-opacity hover:opacity-90">
              <img
                src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
                alt="Job Project"
                className="w-[125px] sm:w-[145px] h-auto object-contain"
              />
            </Link>
          </div>
          <nav className="hidden xl:flex items-center gap-6 2xl:gap-7 text-sm font-medium text-[#111111]">
            <Link to="/" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Home
            </Link>
            <Link to="/o-mnie" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              O Mnie
            </Link>
            <Link
              to="/oferta"
              className="text-[#18c1c9] font-bold transition-colors cursor-pointer"
            >
              Oferta
            </Link>
            <Link to="/zespol" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Zespół
            </Link>
            <Link
              to="/referencje"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Referencje
            </Link>
            <Link to="/blog" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Blog
            </Link>
            <Link
              to="/podreczniki"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Podręczniki
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>

            <Link
              to="/quizy"

              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Quizy
            </Link>
            <a
              href="https://jobproject.com.pl/grupa-mastermind"
              className="hover:text-[#18c1c9] transition-colors cursor-pointer"
            >
              Grupa Mastermind
            </a>
            <Link to="/kontakt" className="hover:text-[#18c1c9] transition-colors cursor-pointer">
              Kontakt
            </Link>
          </nav>
          <div className="flex items-center gap-3 sm:gap-4 shrink-0">
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-xs sm:text-[14px] px-5 sm:px-6 py-2.5 rounded-full transition-all cursor-pointer"
            >
              Darmowa konsultacja
            </button>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <a
                href="https://www.facebook.com/JobProject-Move-your-career-111534800334276"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/facebook-square.svg"
                  alt="Facebook"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
              <a
                href="https://www.linkedin.com/in/magdalenachmieleckalisiecka/"
                target="_blank"
                rel="noreferrer noopener"
              >
                <img
                  src="https://stcdn.leadconnectorhq.com/funnel/icons/square/linkedin-square.svg"
                  alt="LinkedIn"
                  className="w-7 h-7 sm:w-8 sm:h-8"
                />
              </a>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Banner */}
      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center min-h-[220px] flex items-center justify-center"
        style={{
          backgroundImage: `url('https://i.postimg.cc/nLfy5tHT/68ae0e203ba618231cd90ccc.jpg')`,
        }}
      >
        <div className="absolute inset-0 bg-black/40" />
        <h1 className="relative z-10 text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight max-w-4xl px-6 leading-snug">
          Kariera idealnie dobrana do Ciebie – Program coachingowo – szkoleniowy
        </h1>
      </section>

      {/* Introduction */}
      <section className="py-14 bg-white text-center">
        <div className="max-w-[850px] mx-auto px-6 space-y-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#111111]">
            Odkryj do czego masz naturalny talent i co chcesz robić!
          </h2>
          <p className="text-sm sm:text-base text-[#444444] leading-relaxed">
            Jeśli chcesz dokonać świadomego wyboru zawodu w oparciu o potencjał, którym zostałeś/aś
            obdarzony/a i stworzyć plan rozwoju kariery, w którym rozplanujesz jak osiągnąć to, na
            czym Ci zależy ten program jest dla Ciebie. Pracujemy na wygrywającym nagrody narzędziu
            psychometrycznym stworzonym przez coachów i psychologów. Jest to najprawdopodobniej
            jedyne takie narzędzie na rynku, które w sposób naukowy dobiera zawody i obszary
            zawodowe wykorzystujące Twoje atuty i ambicje.
          </p>
        </div>
      </section>

      {/* Dla kogo jest ten program */}
      <section className="py-12 bg-gray-50/50">
        <div className="max-w-[850px] mx-auto px-6">
          <h2 className="text-xl sm:text-2xl font-bold text-center text-[#111111] mb-8">
            Dla kogo jest ten program:
          </h2>
          <div className="bg-white border border-[#18c1c9]/30 rounded-2xl p-6 sm:p-10 shadow-xs space-y-4">
            <ul className="space-y-3">
              {forWhom.map((item, idx) => (
                <li
                  key={idx}
                  className="flex items-start gap-3 text-sm sm:text-base text-[#333333]"
                >
                  <span className="text-[#18c1c9] font-bold text-lg leading-none mt-0.5">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
            <div className="pt-6 border-t border-gray-100 text-sm sm:text-base font-bold text-[#18c1c9] space-y-1">
              <p>Czas trwania programu: 3 miesiące</p>
              <p>Forma pracy: spotkania indywidualne on-line, 10 godzin</p>
            </div>
          </div>
        </div>
      </section>

      {/* Jak będziemy pracować */}
      <section className="py-14 bg-white text-center">
        <div className="max-w-[850px] mx-auto px-6 space-y-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#111111]">Jak będziemy pracować:</h2>
          <p className="text-sm sm:text-base text-[#444444] leading-relaxed">
            Zidentyfikujemy i przeanalizujemy kluczowe obszary wpływające na wybór zawodu, który
            naturalnie pasuje do Ciebie. Zyskasz jasność w czym jesteś dobry/a, gdzie leżą Twoje
            atuty, co Cię wyróżnia. Określimy co jest dla Ciebie istotne aby wykonywana praca dawała
            Ci satysfakcję. Rozpoznasz co leży u podstaw Twojej skuteczności. Popracujemy nad Twoimi
            motywatorami i blokadami. Określimy kluczowe czynniki, aby praca, którą wybierzesz w
            pełni pasowała do Ciebie. Stworzysz PLAN ROZWOJU KARIERY a kiedy to zrobisz, zyskasz
            pewność do czego dążysz i jak to osiągniesz.
          </p>
        </div>
      </section>

      {/* W cenie pakietu otrzymasz */}
      <section className="py-14 bg-gray-50/50">
        <div className="max-w-[850px] mx-auto px-6">
          <h2 className="text-2xl sm:text-3xl font-bold text-center text-[#111111] mb-8">
            W cenie pakietu otrzymasz:
          </h2>
          <div className="bg-white border border-[#18c1c9] rounded-2xl p-6 sm:p-10 shadow-xs space-y-5">
            {includes.map((item, idx) => (
              <div key={idx} className="flex items-start gap-4">
                <img
                  src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/86193b74-6028-4e8b-ba9c-2da1fe007437.svg+xml"
                  alt="Check"
                  className="w-5 h-5 shrink-0 mt-1"
                />
                <p className="text-sm sm:text-base font-medium text-[#222222]">{item}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bottom Banners */}
      <section className="py-12 bg-white text-center border-t border-gray-100">
        <div className="max-w-3xl mx-auto px-6 space-y-5">
          <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-[#111111]">
            Gotowa/y, żeby Twój profil zaczął pracować na Ciebie?
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na bezpłatną konsultację!
            </button>
          </div>
        </div>
      </section>

      <section
        className="relative w-full bg-[#1F4E38] bg-cover bg-center py-20 text-center"
        style={{
          backgroundImage: `url('https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/68af624c8fd78442bc4b62d9.jpeg')`,
        }}
      >
        <div className="relative max-w-4xl mx-auto px-6 space-y-6 z-10">
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-[#faf089] tracking-tight">
            Wrzuć wyższy bieg w swojej karierze !
          </h2>
          <div>
            <button
              onClick={() => openBookingModal("consultation")}
              className="bg-[#18c1c9] hover:bg-[#15adb4] text-white font-medium text-sm sm:text-base px-8 py-3 rounded-full transition-all cursor-pointer"
            >
              Umów się na spotkanie
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white py-12 px-6 sm:px-12 lg:px-20 text-xs text-gray-700">
        <div className="max-w-[1240px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          <div className="space-y-2 text-center md:text-left">
            <h4 className="font-bold text-[#111111] text-sm">Moje produkty</h4>
            <div className="space-y-1">
              <a
                href="https://jobproject.com.pl/poznaj-siebie-zawodowo-page"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Poznaj siebie zawodowo
              </a>
              <a
                href="https://jobproject.com.pl/grupa-mastermind"
                target="_blank"
                rel="noreferrer noopener"
                className="block text-[#444444] hover:text-[#18c1c9] transition-colors"
              >
                Mastermind "Znowu w grze"
              </a>
            </div>
          </div>
          <div className="hidden md:block"></div>
          <div className="bg-[#7cced2] bg-opacity-80 p-6 text-center text-black font-['Roboto',sans-serif] space-y-1">
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link to="/regulamin" className="font-bold italic text-black hover:underline">
                Regulamin usług
              </Link>
            </div>
            <div>
              <span className="font-bold italic">© 2026 | </span>
              <Link
                to="/polityka-prywatnosci"
                className="font-bold italic text-black hover:underline"
              >
                Polityka prywatności
              </Link>
            </div>
          </div>
        </div>
      </footer>

      <ChatWidget />
      <LeadModal isOpen={modalOpen} onClose={() => setModalOpen(false)} type={modalType} />
    </div>
  );
}
