import { createFileRoute, Link } from "@tanstack/react-router";
import gdzieJestemHtml from "./gdzie-jestem-script.html?raw";

export const Route = createFileRoute("/podreczniki/gdzie-jestem-i-co-mnie-blokuje")({
  head: () => ({
    meta: [
      {
        title: "Gdzie Jestem i Co Mnie Blokuje - Interaktywny E-book | Job Project",
      },
      {
        name: "description",
        content:
          "Interaktywny e-book Gdzie Jestem i Co Mnie Blokuje od Job Project - Magdalena Chmielecka-Lisiecka.",
      },
      { property: "og:title", content: "Gdzie Jestem i Co Mnie Blokuje - Interaktywny E-book" },
      {
        property: "og:description",
        content: "Interaktywny e-book Gdzie Jestem i Co Mnie Blokuje od Job Project.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: GdzieJestemICoMnieBlokujePage,
});

export default function GdzieJestemICoMnieBlokujePage() {
  return (
    <div className="min-h-screen bg-[#cfe9ea] font-[Manrope,sans-serif]">
      {/* Navigation Header */}
      <header className="w-full bg-[#F7F5E8] py-3 px-4 sm:px-8 border-b border-[#ebd7b0]/20">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          <Link to="/" className="inline-block transition-opacity hover:opacity-90">
            <img
              src="https://assets.cdn.filesafe.space/qBkeaVOgtwtvWfdxJfrG/media/6895245fe4748854e671fe34.png"
              alt="Job Project"
              className="w-[125px] sm:w-[145px] h-auto object-contain"
            />
          </Link>
          <div className="flex items-center gap-4">
            <Link
              to="/podreczniki"
              className="text-xs sm:text-sm font-semibold text-[#18c1c9] hover:underline"
            >
              ← Powrót do Podręczników
            </Link>
          </div>
        </div>
      </header>

      {/* Embedded Interactive Ebook Script */}
      <main className="py-4 px-2 sm:px-4 max-w-[1440px] mx-auto">
        <iframe
          srcDoc={gdzieJestemHtml}
          className="w-full min-h-[900px] h-[95vh] border-0 rounded-xl bg-transparent"
          title="Gdzie Jestem i Co Mnie Blokuje"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups"
        />
      </main>
    </div>
  );
}
